﻿namespace Craps
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblDice1 = new System.Windows.Forms.Label();
            this.lblDice2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblDiceSum = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lblRolls = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.picPoint10 = new System.Windows.Forms.PictureBox();
            this.picPoint9 = new System.Windows.Forms.PictureBox();
            this.picPoint8 = new System.Windows.Forms.PictureBox();
            this.picPoint6 = new System.Windows.Forms.PictureBox();
            this.picPoint5 = new System.Windows.Forms.PictureBox();
            this.picPoint4 = new System.Windows.Forms.PictureBox();
            this.picDice6 = new System.Windows.Forms.PictureBox();
            this.picDice5 = new System.Windows.Forms.PictureBox();
            this.picDice4 = new System.Windows.Forms.PictureBox();
            this.picDice3 = new System.Windows.Forms.PictureBox();
            this.picDice2 = new System.Windows.Forms.PictureBox();
            this.picDice1 = new System.Windows.Forms.PictureBox();
            this.picBlank2 = new System.Windows.Forms.PictureBox();
            this.picBlank1 = new System.Windows.Forms.PictureBox();
            this.picToken = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lblPoint = new System.Windows.Forms.Label();
            this.lblWon = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.lblLoss = new System.Windows.Forms.Label();
            this.picNothing = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picPoint10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPoint9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPoint8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPoint6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPoint5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPoint4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBlank2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBlank1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picToken)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNothing)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Dice 1";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Dice 2";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDice1
            // 
            this.lblDice1.BackColor = System.Drawing.Color.White;
            this.lblDice1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDice1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDice1.Location = new System.Drawing.Point(68, 87);
            this.lblDice1.Name = "lblDice1";
            this.lblDice1.Size = new System.Drawing.Size(63, 23);
            this.lblDice1.TabIndex = 2;
            // 
            // lblDice2
            // 
            this.lblDice2.BackColor = System.Drawing.Color.White;
            this.lblDice2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDice2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDice2.Location = new System.Drawing.Point(68, 128);
            this.lblDice2.Name = "lblDice2";
            this.lblDice2.Size = new System.Drawing.Size(63, 23);
            this.lblDice2.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Goudy Stout", 39.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(649, 64);
            this.label3.TabIndex = 4;
            this.label3.Text = "C  r  a  p  s";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(138, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(523, 5);
            this.label4.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(138, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(523, 5);
            this.label5.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(138, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(5, 69);
            this.label6.TabIndex = 7;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(398, 87);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(5, 69);
            this.label11.TabIndex = 12;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(656, 87);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(5, 69);
            this.label12.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(138, 210);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(523, 5);
            this.label13.TabIndex = 14;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(138, 146);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(5, 69);
            this.label14.TabIndex = 15;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(656, 146);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(5, 69);
            this.label15.TabIndex = 16;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(398, 146);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(5, 69);
            this.label16.TabIndex = 17;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(312, 87);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(5, 128);
            this.label17.TabIndex = 18;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(225, 87);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(5, 128);
            this.label18.TabIndex = 19;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(484, 87);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(5, 128);
            this.label19.TabIndex = 20;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(568, 87);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(5, 128);
            this.label20.TabIndex = 21;
            // 
            // lblDiceSum
            // 
            this.lblDiceSum.BackColor = System.Drawing.Color.White;
            this.lblDiceSum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDiceSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiceSum.Location = new System.Drawing.Point(38, 192);
            this.lblDiceSum.Name = "lblDiceSum";
            this.lblDiceSum.Size = new System.Drawing.Size(71, 23);
            this.lblDiceSum.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(37, 162);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 23);
            this.label8.TabIndex = 23;
            this.label8.Text = "Dice Sum";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(338, 278);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 44);
            this.button1.TabIndex = 24;
            this.button1.Text = "Roll Dice";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Harlow Solid Italic", 40F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(149, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 59);
            this.label9.TabIndex = 25;
            this.label9.Text = "4";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Harlow Solid Italic", 40F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(236, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 59);
            this.label10.TabIndex = 26;
            this.label10.Text = "5";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Harlow Solid Italic", 40F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(323, 151);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(70, 59);
            this.label21.TabIndex = 27;
            this.label21.Text = "6";
            this.label21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Harlow Solid Italic", 40F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(408, 151);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(70, 59);
            this.label22.TabIndex = 28;
            this.label22.Text = "8";
            this.label22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Harlow Solid Italic", 40F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(496, 151);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 59);
            this.label23.TabIndex = 29;
            this.label23.Text = "9";
            this.label23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Harlow Solid Italic", 40F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(573, 151);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(80, 59);
            this.label24.TabIndex = 30;
            this.label24.Text = "10";
            this.label24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label25
            // 
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(35, 221);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(74, 23);
            this.label25.TabIndex = 33;
            this.label25.Text = "Rolls";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRolls
            // 
            this.lblRolls.BackColor = System.Drawing.Color.White;
            this.lblRolls.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRolls.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRolls.Location = new System.Drawing.Point(38, 248);
            this.lblRolls.Name = "lblRolls";
            this.lblRolls.Size = new System.Drawing.Size(71, 23);
            this.lblRolls.TabIndex = 34;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(138, 215);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(5, 236);
            this.label27.TabIndex = 35;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(138, 387);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(523, 5);
            this.label28.TabIndex = 36;
            // 
            // label29
            // 
            this.label29.Font = new System.Drawing.Font("Stencil", 39.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(149, 393);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(512, 59);
            this.label29.TabIndex = 37;
            this.label29.Text = "Pass Line";
            this.label29.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // picPoint10
            // 
            this.picPoint10.Location = new System.Drawing.Point(585, 95);
            this.picPoint10.Name = "picPoint10";
            this.picPoint10.Size = new System.Drawing.Size(61, 48);
            this.picPoint10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPoint10.TabIndex = 49;
            this.picPoint10.TabStop = false;
            // 
            // picPoint9
            // 
            this.picPoint9.Location = new System.Drawing.Point(499, 95);
            this.picPoint9.Name = "picPoint9";
            this.picPoint9.Size = new System.Drawing.Size(61, 48);
            this.picPoint9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPoint9.TabIndex = 48;
            this.picPoint9.TabStop = false;
            // 
            // picPoint8
            // 
            this.picPoint8.Location = new System.Drawing.Point(413, 95);
            this.picPoint8.Name = "picPoint8";
            this.picPoint8.Size = new System.Drawing.Size(61, 48);
            this.picPoint8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPoint8.TabIndex = 47;
            this.picPoint8.TabStop = false;
            // 
            // picPoint6
            // 
            this.picPoint6.Location = new System.Drawing.Point(328, 95);
            this.picPoint6.Name = "picPoint6";
            this.picPoint6.Size = new System.Drawing.Size(61, 48);
            this.picPoint6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPoint6.TabIndex = 46;
            this.picPoint6.TabStop = false;
            // 
            // picPoint5
            // 
            this.picPoint5.Location = new System.Drawing.Point(241, 95);
            this.picPoint5.Name = "picPoint5";
            this.picPoint5.Size = new System.Drawing.Size(61, 48);
            this.picPoint5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPoint5.TabIndex = 45;
            this.picPoint5.TabStop = false;
            // 
            // picPoint4
            // 
            this.picPoint4.Location = new System.Drawing.Point(153, 95);
            this.picPoint4.Name = "picPoint4";
            this.picPoint4.Size = new System.Drawing.Size(61, 48);
            this.picPoint4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPoint4.TabIndex = 44;
            this.picPoint4.TabStop = false;
            // 
            // picDice6
            // 
            this.picDice6.Image = global::Craps.Properties.Resources.Dice6;
            this.picDice6.Location = new System.Drawing.Point(621, 395);
            this.picDice6.Name = "picDice6";
            this.picDice6.Size = new System.Drawing.Size(43, 38);
            this.picDice6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDice6.TabIndex = 43;
            this.picDice6.TabStop = false;
            this.picDice6.Visible = false;
            // 
            // picDice5
            // 
            this.picDice5.Image = global::Craps.Properties.Resources.Dice5;
            this.picDice5.Location = new System.Drawing.Point(572, 395);
            this.picDice5.Name = "picDice5";
            this.picDice5.Size = new System.Drawing.Size(43, 38);
            this.picDice5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDice5.TabIndex = 42;
            this.picDice5.TabStop = false;
            this.picDice5.Visible = false;
            // 
            // picDice4
            // 
            this.picDice4.Image = global::Craps.Properties.Resources.Dice4;
            this.picDice4.Location = new System.Drawing.Point(523, 395);
            this.picDice4.Name = "picDice4";
            this.picDice4.Size = new System.Drawing.Size(43, 38);
            this.picDice4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDice4.TabIndex = 41;
            this.picDice4.TabStop = false;
            this.picDice4.Visible = false;
            // 
            // picDice3
            // 
            this.picDice3.Image = global::Craps.Properties.Resources.Dice3;
            this.picDice3.Location = new System.Drawing.Point(247, 395);
            this.picDice3.Name = "picDice3";
            this.picDice3.Size = new System.Drawing.Size(43, 38);
            this.picDice3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDice3.TabIndex = 40;
            this.picDice3.TabStop = false;
            this.picDice3.Visible = false;
            // 
            // picDice2
            // 
            this.picDice2.Image = global::Craps.Properties.Resources.Dice2;
            this.picDice2.Location = new System.Drawing.Point(198, 395);
            this.picDice2.Name = "picDice2";
            this.picDice2.Size = new System.Drawing.Size(43, 38);
            this.picDice2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDice2.TabIndex = 39;
            this.picDice2.TabStop = false;
            this.picDice2.Visible = false;
            // 
            // picDice1
            // 
            this.picDice1.Image = global::Craps.Properties.Resources.Dice1;
            this.picDice1.Location = new System.Drawing.Point(149, 395);
            this.picDice1.Name = "picDice1";
            this.picDice1.Size = new System.Drawing.Size(43, 38);
            this.picDice1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDice1.TabIndex = 38;
            this.picDice1.TabStop = false;
            this.picDice1.Visible = false;
            // 
            // picBlank2
            // 
            this.picBlank2.Location = new System.Drawing.Point(487, 236);
            this.picBlank2.Name = "picBlank2";
            this.picBlank2.Size = new System.Drawing.Size(142, 122);
            this.picBlank2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBlank2.TabIndex = 32;
            this.picBlank2.TabStop = false;
            // 
            // picBlank1
            // 
            this.picBlank1.Location = new System.Drawing.Point(175, 236);
            this.picBlank1.Name = "picBlank1";
            this.picBlank1.Size = new System.Drawing.Size(142, 122);
            this.picBlank1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBlank1.TabIndex = 31;
            this.picBlank1.TabStop = false;
            // 
            // picToken
            // 
            this.picToken.Image = global::Craps.Properties.Resources.Point;
            this.picToken.Location = new System.Drawing.Point(153, 95);
            this.picToken.Name = "picToken";
            this.picToken.Size = new System.Drawing.Size(43, 38);
            this.picToken.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picToken.TabIndex = 50;
            this.picToken.TabStop = false;
            this.picToken.Visible = false;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(28, 278);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 23);
            this.label7.TabIndex = 51;
            this.label7.Text = "Your Point";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPoint
            // 
            this.lblPoint.BackColor = System.Drawing.Color.White;
            this.lblPoint.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPoint.Location = new System.Drawing.Point(38, 302);
            this.lblPoint.Name = "lblPoint";
            this.lblPoint.Size = new System.Drawing.Size(71, 23);
            this.lblPoint.TabIndex = 52;
            // 
            // lblWon
            // 
            this.lblWon.BackColor = System.Drawing.Color.White;
            this.lblWon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblWon.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWon.Location = new System.Drawing.Point(38, 360);
            this.lblWon.Name = "lblWon";
            this.lblWon.Size = new System.Drawing.Size(71, 23);
            this.lblWon.TabIndex = 53;
            // 
            // label31
            // 
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(28, 335);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(94, 23);
            this.label31.TabIndex = 54;
            this.label31.Text = "Games Won";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(26, 388);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(94, 23);
            this.label32.TabIndex = 55;
            this.label32.Text = "Games Loss";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLoss
            // 
            this.lblLoss.BackColor = System.Drawing.Color.White;
            this.lblLoss.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblLoss.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoss.Location = new System.Drawing.Point(38, 415);
            this.lblLoss.Name = "lblLoss";
            this.lblLoss.Size = new System.Drawing.Size(71, 23);
            this.lblLoss.TabIndex = 56;
            // 
            // picNothing
            // 
            this.picNothing.Location = new System.Drawing.Point(368, 340);
            this.picNothing.Name = "picNothing";
            this.picNothing.Size = new System.Drawing.Size(63, 32);
            this.picNothing.TabIndex = 57;
            this.picNothing.TabStop = false;
            this.picNothing.Visible = false;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(673, 461);
            this.Controls.Add(this.picNothing);
            this.Controls.Add(this.lblLoss);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.lblWon);
            this.Controls.Add(this.lblPoint);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.picToken);
            this.Controls.Add(this.picPoint10);
            this.Controls.Add(this.picPoint9);
            this.Controls.Add(this.picPoint8);
            this.Controls.Add(this.picPoint6);
            this.Controls.Add(this.picPoint5);
            this.Controls.Add(this.picPoint4);
            this.Controls.Add(this.picDice6);
            this.Controls.Add(this.picDice5);
            this.Controls.Add(this.picDice4);
            this.Controls.Add(this.picDice3);
            this.Controls.Add(this.picDice2);
            this.Controls.Add(this.picDice1);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.lblRolls);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.picBlank2);
            this.Controls.Add(this.picBlank1);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblDiceSum);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblDice2);
            this.Controls.Add(this.lblDice1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmMain";
            this.Text = "Craps";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picPoint10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPoint9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPoint8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPoint6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPoint5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPoint4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBlank2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBlank1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picToken)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNothing)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblDice1;
        private System.Windows.Forms.Label lblDice2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblDiceSum;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox picBlank1;
        private System.Windows.Forms.PictureBox picBlank2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lblRolls;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.PictureBox picDice1;
        private System.Windows.Forms.PictureBox picDice2;
        private System.Windows.Forms.PictureBox picDice3;
        private System.Windows.Forms.PictureBox picDice4;
        private System.Windows.Forms.PictureBox picDice5;
        private System.Windows.Forms.PictureBox picDice6;
        private System.Windows.Forms.PictureBox picPoint4;
        private System.Windows.Forms.PictureBox picPoint5;
        private System.Windows.Forms.PictureBox picPoint6;
        private System.Windows.Forms.PictureBox picPoint8;
        private System.Windows.Forms.PictureBox picPoint9;
        private System.Windows.Forms.PictureBox picPoint10;
        private System.Windows.Forms.PictureBox picToken;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblPoint;
        private System.Windows.Forms.Label lblWon;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label lblLoss;
        private System.Windows.Forms.PictureBox picNothing;
    }
}

