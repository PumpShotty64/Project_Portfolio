﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Craps
{
    public partial class frmMain : Form
    {
        private decimal totalRolls;
        private decimal Won;
        private decimal Loss;



        public frmMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //sets a variable
            decimal TotalSumDecimal;
                       

            //this generates a random number
            System.Random r = new System.Random((int)System.DateTime.Now.Ticks);
            int myRandom = r.Next(1, 7);
            int myRandom2 = r.Next(1, 7);

            //output the numbers
            lblDice1.Text = myRandom.ToString();
            lblDice2.Text = myRandom2.ToString();
            //makes images visible
            picBlank1.Visible = true;
            picBlank2.Visible = true;

            //this spawns a picture depending on what number is chosen
            if (myRandom == 1)
            {
                picBlank1.Image = picDice1.Image;
            }
            else if (myRandom == 2)
            {
                picBlank1.Image = picDice2.Image;
            }
            else if (myRandom == 3)
            {
                picBlank1.Image = picDice3.Image;
            }
            else if (myRandom == 4)
            {
                picBlank1.Image = picDice4.Image;
            }
            else if (myRandom == 5)
            {
                picBlank1.Image = picDice5.Image;
            }
            else if (myRandom == 6)
            {
                picBlank1.Image = picDice6.Image;
            }
            if (myRandom2 == 1)
            {
                picBlank2.Image = picDice1.Image;
            }
            else if (myRandom2 == 2)
            {
                picBlank2.Image = picDice2.Image;
            }
            else if (myRandom2 == 3)
            {
                picBlank2.Image = picDice3.Image;
            }
            else if (myRandom2 == 4)
            {
                picBlank2.Image = picDice4.Image;
            }
            else if (myRandom2 == 5)
            {
                picBlank2.Image = picDice5.Image;
            }
            else if (myRandom2 == 6)
            {
                picBlank2.Image = picDice6.Image;
            }
            
            //Calculations of sum and number of rolls
            TotalSumDecimal = myRandom + myRandom2;
            totalRolls += 1;

            //calculates the game mechanics of craps
            
            if (TotalSumDecimal == 4 && totalRolls == 1)
            {
                picPoint4.Image = picToken.Image;
                lblPoint.Text = "4";
            }
           
            else if (TotalSumDecimal == 5 && totalRolls == 1)
            {
                picPoint5.Image = picToken.Image;
                lblPoint.Text = "5";
            }
            
            else if (TotalSumDecimal == 6 && totalRolls == 1)
            {
                picPoint6.Image = picToken.Image;
                lblPoint.Text = "6";
            }
            
            else if (TotalSumDecimal == 8 && totalRolls == 1)
            {
                picPoint8.Image = picToken.Image;
                lblPoint.Text = "8";
            }
           
            else if (TotalSumDecimal == 9 && totalRolls == 1)
            {
                picPoint9.Image = picToken.Image;
                lblPoint.Text = "9";
            }
            
            else if (TotalSumDecimal == 10 && totalRolls == 1)
            {
                picPoint10.Image = picToken.Image;
                lblPoint.Text = "10";
            }

            //Output Answers of sum
            lblDiceSum.Text = TotalSumDecimal.ToString();
            lblRolls.Text = totalRolls.ToString();

            if (TotalSumDecimal == 4 && picPoint4.Image == picToken.Image && totalRolls >= 2)
            {
                MessageBox.Show("You Win!", "Winner",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                Won += 1;
                totalRolls = 0;
                TotalSumDecimal = 0;
                lblPoint.Text = "";
                picPoint4.Image = picNothing.Image;
                picBlank1.Image = picNothing.Image;
                picBlank2.Image = picNothing.Image;
                lblDice1.Text = "";
                lblDice2.Text = "";
                lblDiceSum.Text = "";
                lblRolls.Text = "";
            }
            else if (TotalSumDecimal == 5 && picPoint5.Image == picToken.Image && totalRolls >= 2)
            {
                MessageBox.Show("You Win!", "Winner",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                Won += 1;
                totalRolls = 0;
                TotalSumDecimal = 0;
                lblPoint.Text = "";
                picPoint5.Image = picNothing.Image;
                picBlank1.Image = picNothing.Image;
                picBlank2.Image = picNothing.Image;
                lblDice1.Text = "";
                lblDice2.Text = "";
                lblDiceSum.Text = "";
                lblRolls.Text = "";
            }
            else if (TotalSumDecimal == 6 && picPoint6.Image == picToken.Image && totalRolls >= 2)
            {
                MessageBox.Show("You Win!", "Winner",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                Won += 1;
                totalRolls = 0;
                TotalSumDecimal = 0;
                lblPoint.Text = "";
                picPoint6.Image = picNothing.Image;
                picBlank1.Image = picNothing.Image;
                picBlank2.Image = picNothing.Image;
                lblDice1.Text = "";
                lblDice2.Text = "";
                lblDiceSum.Text = "";
                lblRolls.Text = "";
            }
            else if (TotalSumDecimal == 7 && totalRolls >= 2)
            {
                MessageBox.Show("You Lose!", "Loser",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                Loss += 1;
                totalRolls = 0;
                TotalSumDecimal = 0;
                lblPoint.Text = "";
                picPoint4.Image = picNothing.Image;
                picPoint5.Image = picNothing.Image;
                picPoint6.Image = picNothing.Image;
                picPoint8.Image = picNothing.Image;
                picPoint9.Image = picNothing.Image;
                picPoint10.Image = picNothing.Image;
                picBlank1.Image = picNothing.Image;
                picBlank2.Image = picNothing.Image;
                lblDice1.Text = "";
                lblDice2.Text = "";
                lblDiceSum.Text = "";
                lblRolls.Text = "";
            }
            else if (TotalSumDecimal == 8 && picPoint8.Image == picToken.Image && totalRolls >= 2)
            {
                MessageBox.Show("You Win!", "Winner",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                Won += 1;
                totalRolls = 0;
                TotalSumDecimal = 0;
                lblPoint.Text = "";
                picPoint8.Image = picNothing.Image;
                picBlank1.Image = picNothing.Image;
                picBlank2.Image = picNothing.Image;
                lblDice1.Text = "";
                lblDice2.Text = "";
                lblDiceSum.Text = "";
                lblRolls.Text = "";
            }
            else if (TotalSumDecimal == 9 && picPoint9.Image == picToken.Image && totalRolls >= 2)
            {
                MessageBox.Show("You Win!", "Winner",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                Won += 1;
                totalRolls = 0;
                TotalSumDecimal = 0;
                lblPoint.Text = "";
                picPoint9.Image = picNothing.Image;
                picBlank1.Image = picNothing.Image;
                picBlank2.Image = picNothing.Image;
                lblDice1.Text = "";
                lblDice2.Text = "";
                lblDiceSum.Text = "";
                lblRolls.Text = "";
            }
            else if (TotalSumDecimal == 10 && picPoint10.Image == picToken.Image && totalRolls >= 2)
            {
                MessageBox.Show("You Win!", "Winner",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                Won += 1;
                totalRolls = 0;
                TotalSumDecimal = 0;
                lblPoint.Text = "";
                picPoint10.Image = picNothing.Image;
                picBlank1.Image = picNothing.Image;
                picBlank2.Image = picNothing.Image;
                lblDice1.Text = "";
                lblDice2.Text = "";
                lblDiceSum.Text = "";
                lblRolls.Text = "";
            }
            else if (TotalSumDecimal == 2 && totalRolls == 1)
            {
                MessageBox.Show("You Lose!", "Loser",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                Loss += 1;
                totalRolls = 0;
                TotalSumDecimal = 0;
                lblPoint.Text = "";
                picPoint4.Image = picNothing.Image;
                picPoint5.Image = picNothing.Image;
                picPoint6.Image = picNothing.Image;
                picPoint8.Image = picNothing.Image;
                picPoint9.Image = picNothing.Image;
                picPoint10.Image = picNothing.Image;
                picBlank1.Image = picNothing.Image;
                picBlank2.Image = picNothing.Image;
                lblDice1.Text = "";
                lblDice2.Text = "";
                lblDiceSum.Text = "";
                lblRolls.Text = "";
            }
            else if (TotalSumDecimal == 3 && totalRolls == 1)
            {
                MessageBox.Show("You Lose!", "Loser",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                Loss += 1;
                totalRolls = 0;
                TotalSumDecimal = 0;
                lblPoint.Text = "";
                picPoint4.Image = picNothing.Image;
                picPoint5.Image = picNothing.Image;
                picPoint6.Image = picNothing.Image;
                picPoint8.Image = picNothing.Image;
                picPoint9.Image = picNothing.Image;
                picPoint10.Image = picNothing.Image;
                picBlank1.Image = picNothing.Image;
                picBlank2.Image = picNothing.Image;
                lblDice1.Text = "";
                lblDice2.Text = "";
                lblDiceSum.Text = "";
                lblRolls.Text = "";
            }
            else if (TotalSumDecimal == 12 && totalRolls == 1)
            {
                MessageBox.Show("You Lose!", "Loser",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                Loss += 1;
                totalRolls = 0;
                TotalSumDecimal = 0;
                lblPoint.Text = "";
                picPoint4.Image = picNothing.Image;
                picPoint5.Image = picNothing.Image;
                picPoint6.Image = picNothing.Image;
                picPoint8.Image = picNothing.Image;
                picPoint9.Image = picNothing.Image;
                picPoint10.Image = picNothing.Image;
                picBlank1.Image = picNothing.Image;
                picBlank2.Image = picNothing.Image;
                lblDice1.Text = "";
                lblDice2.Text = "";
                lblDiceSum.Text = "";
                lblRolls.Text = "";
            }
            else if (TotalSumDecimal == 7 && totalRolls == 1)
            {
                MessageBox.Show("You Win!", "Winner",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                Won += 1;
                totalRolls = 0;
                TotalSumDecimal = 0;
                lblPoint.Text = "";
                picPoint4.Image = picNothing.Image;
                picPoint5.Image = picNothing.Image;
                picPoint6.Image = picNothing.Image;
                picPoint8.Image = picNothing.Image;
                picPoint9.Image = picNothing.Image;
                picPoint10.Image = picNothing.Image;
                picBlank1.Image = picNothing.Image;
                picBlank2.Image = picNothing.Image;
                lblDice1.Text = "";
                lblDice2.Text = "";
                lblDiceSum.Text = "";
                lblRolls.Text = "";
            }
            else if (TotalSumDecimal == 11 && totalRolls == 1)
            {
                MessageBox.Show("You Win!", "Winner",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                Won += 1;
                totalRolls = 0;
                TotalSumDecimal = 0;
                lblPoint.Text = "";
                picPoint4.Image = picNothing.Image;
                picPoint5.Image = picNothing.Image;
                picPoint6.Image = picNothing.Image;
                picPoint8.Image = picNothing.Image;
                picPoint9.Image = picNothing.Image;
                picPoint10.Image = picNothing.Image;
                picBlank1.Image = picNothing.Image;
                picBlank2.Image = picNothing.Image;
                lblDice1.Text = "";
                lblDice2.Text = "";
                lblDiceSum.Text = "";
                lblRolls.Text = "";
            }

            //outputs the win and lose statistics
            lblWon.Text = Won.ToString();
            lblLoss.Text = Loss.ToString();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }
    }
}
