﻿namespace TicTacToe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.humanVsHumanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.humanVsAIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.PicBox1 = new System.Windows.Forms.PictureBox();
            this.PicBox2 = new System.Windows.Forms.PictureBox();
            this.PicBox3 = new System.Windows.Forms.PictureBox();
            this.PicBox6 = new System.Windows.Forms.PictureBox();
            this.PicBox5 = new System.Windows.Forms.PictureBox();
            this.PicBox4 = new System.Windows.Forms.PictureBox();
            this.PicBox7 = new System.Windows.Forms.PictureBox();
            this.PicBox8 = new System.Windows.Forms.PictureBox();
            this.PicBox9 = new System.Windows.Forms.PictureBox();
            this.picX = new System.Windows.Forms.PictureBox();
            this.picO = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picO)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("OCR A Extended", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(353, 49);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tic Tac Toe";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("OCR A Extended", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(353, 2);
            this.label2.TabIndex = 1;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Black;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F);
            this.label11.Location = new System.Drawing.Point(32, 187);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(312, 6);
            this.label11.TabIndex = 11;
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Black;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F);
            this.label12.Location = new System.Drawing.Point(32, 292);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(312, 6);
            this.label12.TabIndex = 12;
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Black;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F);
            this.label13.Location = new System.Drawing.Point(132, 87);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(6, 311);
            this.label13.TabIndex = 13;
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Black;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F);
            this.label14.Location = new System.Drawing.Point(238, 87);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(6, 311);
            this.label14.TabIndex = 14;
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gameToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(377, 24);
            this.menuStrip1.TabIndex = 15;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // gameToolStripMenuItem
            // 
            this.gameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.gameToolStripMenuItem.Name = "gameToolStripMenuItem";
            this.gameToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.gameToolStripMenuItem.Text = "Game";
            // 
            // newGameToolStripMenuItem
            // 
            this.newGameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.humanVsHumanToolStripMenuItem,
            this.humanVsAIToolStripMenuItem});
            this.newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            this.newGameToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.newGameToolStripMenuItem.Text = "New Game";
            // 
            // humanVsHumanToolStripMenuItem
            // 
            this.humanVsHumanToolStripMenuItem.Name = "humanVsHumanToolStripMenuItem";
            this.humanVsHumanToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.humanVsHumanToolStripMenuItem.Text = "Human vs. Human";
            this.humanVsHumanToolStripMenuItem.Click += new System.EventHandler(this.humanVsHumanToolStripMenuItem_Click);
            // 
            // humanVsAIToolStripMenuItem
            // 
            this.humanVsAIToolStripMenuItem.Name = "humanVsAIToolStripMenuItem";
            this.humanVsAIToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.humanVsAIToolStripMenuItem.Text = "Human vs. AI";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label3.Location = new System.Drawing.Point(287, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 24);
            this.label3.TabIndex = 16;
            this.label3.Text = "Jordan Nguyen";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // PicBox1
            // 
            this.PicBox1.BackColor = System.Drawing.Color.White;
            this.PicBox1.Location = new System.Drawing.Point(32, 87);
            this.PicBox1.Name = "PicBox1";
            this.PicBox1.Size = new System.Drawing.Size(100, 100);
            this.PicBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBox1.TabIndex = 17;
            this.PicBox1.TabStop = false;
            this.PicBox1.Click += new System.EventHandler(this.PicBox1_Click);
            // 
            // PicBox2
            // 
            this.PicBox2.BackColor = System.Drawing.Color.White;
            this.PicBox2.Location = new System.Drawing.Point(138, 87);
            this.PicBox2.Name = "PicBox2";
            this.PicBox2.Size = new System.Drawing.Size(100, 100);
            this.PicBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBox2.TabIndex = 18;
            this.PicBox2.TabStop = false;
            this.PicBox2.Click += new System.EventHandler(this.PicBox2_Click);
            // 
            // PicBox3
            // 
            this.PicBox3.BackColor = System.Drawing.Color.White;
            this.PicBox3.Location = new System.Drawing.Point(244, 87);
            this.PicBox3.Name = "PicBox3";
            this.PicBox3.Size = new System.Drawing.Size(100, 100);
            this.PicBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBox3.TabIndex = 19;
            this.PicBox3.TabStop = false;
            this.PicBox3.Click += new System.EventHandler(this.PicBox3_Click);
            // 
            // PicBox6
            // 
            this.PicBox6.BackColor = System.Drawing.Color.White;
            this.PicBox6.Location = new System.Drawing.Point(244, 193);
            this.PicBox6.Name = "PicBox6";
            this.PicBox6.Size = new System.Drawing.Size(100, 100);
            this.PicBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBox6.TabIndex = 20;
            this.PicBox6.TabStop = false;
            this.PicBox6.Click += new System.EventHandler(this.PicBox6_Click);
            // 
            // PicBox5
            // 
            this.PicBox5.BackColor = System.Drawing.Color.White;
            this.PicBox5.Location = new System.Drawing.Point(138, 193);
            this.PicBox5.Name = "PicBox5";
            this.PicBox5.Size = new System.Drawing.Size(100, 100);
            this.PicBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBox5.TabIndex = 21;
            this.PicBox5.TabStop = false;
            this.PicBox5.Click += new System.EventHandler(this.PicBox5_Click);
            // 
            // PicBox4
            // 
            this.PicBox4.BackColor = System.Drawing.Color.White;
            this.PicBox4.Location = new System.Drawing.Point(32, 193);
            this.PicBox4.Name = "PicBox4";
            this.PicBox4.Size = new System.Drawing.Size(100, 100);
            this.PicBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBox4.TabIndex = 22;
            this.PicBox4.TabStop = false;
            this.PicBox4.Click += new System.EventHandler(this.PicBox4_Click);
            // 
            // PicBox7
            // 
            this.PicBox7.BackColor = System.Drawing.Color.White;
            this.PicBox7.Location = new System.Drawing.Point(32, 298);
            this.PicBox7.Name = "PicBox7";
            this.PicBox7.Size = new System.Drawing.Size(100, 100);
            this.PicBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBox7.TabIndex = 23;
            this.PicBox7.TabStop = false;
            this.PicBox7.Click += new System.EventHandler(this.PicBox7_Click);
            // 
            // PicBox8
            // 
            this.PicBox8.BackColor = System.Drawing.Color.White;
            this.PicBox8.Location = new System.Drawing.Point(138, 298);
            this.PicBox8.Name = "PicBox8";
            this.PicBox8.Size = new System.Drawing.Size(100, 100);
            this.PicBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBox8.TabIndex = 24;
            this.PicBox8.TabStop = false;
            this.PicBox8.Click += new System.EventHandler(this.PicBox8_Click);
            // 
            // PicBox9
            // 
            this.PicBox9.BackColor = System.Drawing.Color.White;
            this.PicBox9.Location = new System.Drawing.Point(244, 298);
            this.PicBox9.Name = "PicBox9";
            this.PicBox9.Size = new System.Drawing.Size(100, 100);
            this.PicBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBox9.TabIndex = 25;
            this.PicBox9.TabStop = false;
            this.PicBox9.Click += new System.EventHandler(this.PicBox9_Click);
            // 
            // picX
            // 
            this.picX.BackColor = System.Drawing.Color.White;
            this.picX.Image = global::TicTacToe.Properties.Resources.X;
            this.picX.Location = new System.Drawing.Point(12, 39);
            this.picX.Name = "picX";
            this.picX.Size = new System.Drawing.Size(33, 31);
            this.picX.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picX.TabIndex = 26;
            this.picX.TabStop = false;
            this.picX.Visible = false;
            // 
            // picO
            // 
            this.picO.BackColor = System.Drawing.Color.White;
            this.picO.Image = global::TicTacToe.Properties.Resources.O;
            this.picO.Location = new System.Drawing.Point(332, 39);
            this.picO.Name = "picO";
            this.picO.Size = new System.Drawing.Size(33, 31);
            this.picO.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picO.TabIndex = 27;
            this.picO.TabStop = false;
            this.picO.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(377, 407);
            this.Controls.Add(this.picO);
            this.Controls.Add(this.picX);
            this.Controls.Add(this.PicBox9);
            this.Controls.Add(this.PicBox8);
            this.Controls.Add(this.PicBox7);
            this.Controls.Add(this.PicBox4);
            this.Controls.Add(this.PicBox5);
            this.Controls.Add(this.PicBox6);
            this.Controls.Add(this.PicBox3);
            this.Controls.Add(this.PicBox2);
            this.Controls.Add(this.PicBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Tic Tac Toe";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picO)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem humanVsHumanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem humanVsAIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox PicBox1;
        private System.Windows.Forms.PictureBox PicBox2;
        private System.Windows.Forms.PictureBox PicBox3;
        private System.Windows.Forms.PictureBox PicBox6;
        private System.Windows.Forms.PictureBox PicBox5;
        private System.Windows.Forms.PictureBox PicBox4;
        private System.Windows.Forms.PictureBox PicBox7;
        private System.Windows.Forms.PictureBox PicBox8;
        private System.Windows.Forms.PictureBox PicBox9;
        private System.Windows.Forms.PictureBox picX;
        private System.Windows.Forms.PictureBox picO;
    }
}

