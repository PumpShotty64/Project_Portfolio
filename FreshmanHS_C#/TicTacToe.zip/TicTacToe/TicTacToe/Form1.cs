﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    //Jordan Nguyen
    //Period 0
    //2/20/15
    //This program simulates a tic tac toe game.
    public partial class Form1 : Form
    {
        //declare our global variables
        int counter = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //closes program
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void humanVsHumanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //creats new game
            PicBox1.Image = null;
            PicBox2.Image = null;
            PicBox3.Image = null;
            PicBox4.Image = null;
            PicBox5.Image = null;
            PicBox6.Image = null;
            PicBox7.Image = null;
            PicBox8.Image = null;
            PicBox9.Image = null;
            PicBox1.Enabled = true;
            PicBox2.Enabled = true;
            PicBox3.Enabled = true;
            PicBox4.Enabled = true;
            PicBox5.Enabled = true;
            PicBox6.Enabled = true;
            PicBox7.Enabled = true;
            PicBox8.Enabled = true;
            PicBox9.Enabled = true;
            counter = 0;
        }

        private void PicBox1_Click(object sender, EventArgs e)
        {
            //outputs picture X or O
            counter ++;
            int oddEven = counter % 2;
           
            if (oddEven != 0)
            {
                PicBox1.Image = picX.Image;
                PicBox1.Enabled = false;
            }
            else if (oddEven == 0)
            {
                PicBox1.Image = picO.Image;
                PicBox1.Enabled = false;
            }
            WinLose();
        }

        private void PicBox2_Click(object sender, EventArgs e)
        {
            counter++;
            int oddEven = counter % 2;

            if (oddEven != 0)
            {
                PicBox2.Image = picX.Image;
                PicBox2.Enabled = false;
            }
            else if (oddEven == 0)
            {
                PicBox2.Image = picO.Image;
                PicBox2.Enabled = false;
            }
            WinLose();
        }

        private void PicBox3_Click(object sender, EventArgs e)
        {
            counter++;
            int oddEven = counter % 2;

            if (oddEven != 0)
            {
                PicBox3.Image = picX.Image;
                PicBox3.Enabled = false;
            }
            else if (oddEven == 0)
            {
                PicBox3.Image = picO.Image;
                PicBox3.Enabled = false;
            }
            WinLose();
        }

        private void PicBox4_Click(object sender, EventArgs e)
        {
            counter++;
            int oddEven = counter % 2;

            if (oddEven != 0)
            {
                PicBox4.Image = picX.Image;
                PicBox4.Enabled = false;
            }
            else if (oddEven == 0)
            {
                PicBox4.Image = picO.Image;
                PicBox4.Enabled = false;
            }
            WinLose();
        }

        private void PicBox5_Click(object sender, EventArgs e)
        {
            counter++;
            int oddEven = counter % 2;

            if (oddEven != 0)
            {
                PicBox5.Image = picX.Image;
                PicBox5.Enabled = false;
            }
            else if (oddEven == 0)
            {
                PicBox5.Image = picO.Image;
                PicBox5.Enabled = false;
            }
            WinLose();
        }

        private void PicBox6_Click(object sender, EventArgs e)
        {
            counter++;
            int oddEven = counter % 2;

            if (oddEven != 0)
            {
                PicBox6.Image = picX.Image;
                PicBox6.Enabled = false;
            }
            else if (oddEven == 0)
            {
                PicBox6.Image = picO.Image;
                PicBox6.Enabled = false;
            }
            WinLose();
        }

        private void PicBox7_Click(object sender, EventArgs e)
        {
            counter++;
            int oddEven = counter % 2;

            if (oddEven != 0)
            {
                PicBox7.Image = picX.Image;
                PicBox7.Enabled = false;
            }
            else if (oddEven == 0)
            {
                PicBox7.Image = picO.Image;
                PicBox7.Enabled = false;
            }
            WinLose();
        }

        private void PicBox8_Click(object sender, EventArgs e)
        {
            counter++;
            int oddEven = counter % 2;

            if (oddEven != 0)
            {
                PicBox8.Image = picX.Image;
                PicBox8.Enabled = false;
            }
            else if (oddEven == 0)
            {
                PicBox8.Image = picO.Image;
                PicBox8.Enabled = false;
            }
            WinLose();
        }

        private void PicBox9_Click(object sender, EventArgs e)
        {
            counter++;
            int oddEven = counter % 2;

            if (oddEven != 0)
            {
                PicBox9.Image = picX.Image;
                PicBox9.Enabled = false;
            }
            else if (oddEven == 0)
            {
                PicBox9.Image = picO.Image;
                PicBox9.Enabled = false;
            }
            WinLose();
        }

        private void WinLose()
        {
            //Result of the game
            DialogResult resultAnswer = DialogResult;
            //win lose conditions
            if (PicBox1.Image == PicBox2.Image && PicBox2.Image == PicBox3.Image && PicBox1.Image != null)
            {
                resultAnswer = MessageBox.Show("That's the Game! Do you want to play again?", "Game Result",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            }
            else if (PicBox4.Image == PicBox5.Image && PicBox5.Image == PicBox6.Image && PicBox4.Image != null)
            {
                resultAnswer = MessageBox.Show("That's the Game! Do you want to play again?", "Game Result",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            }
            else if (PicBox7.Image == PicBox8.Image && PicBox8.Image == PicBox9.Image && PicBox7.Image != null)
            {
                resultAnswer = MessageBox.Show("That's the Game! Do you want to play again?", "Game Result",
                   MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            }
            else if (PicBox1.Image == PicBox4.Image && PicBox4.Image == PicBox7.Image && PicBox1.Image != null)
            {
                resultAnswer = MessageBox.Show("That's the Game! Do you want to play again?", "Game Result",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            }
            else if (PicBox2.Image == PicBox5.Image && PicBox5.Image == PicBox8.Image && PicBox2.Image != null)
            {
                resultAnswer = MessageBox.Show("That's the Game! Do you want to play again?", "Game Result",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            }
            else if (PicBox3.Image == PicBox6.Image && PicBox6.Image == PicBox9.Image && PicBox3.Image != null)
            {
                resultAnswer = MessageBox.Show("That's the Game! Do you want to play again?", "Game Result",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            }
            else if (PicBox1.Image == PicBox5.Image && PicBox5.Image == PicBox9.Image && PicBox1.Image != null)
            {
                resultAnswer = MessageBox.Show("That's the Game! Do you want to play again?", "Game Result",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            }
            else if (PicBox3.Image == PicBox5.Image && PicBox5.Image == PicBox7.Image && PicBox3.Image != null)
            {
                resultAnswer = MessageBox.Show("That's the Game! Do you want to play again?", "Game Result",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            }
            else
            {
                if (counter == 9)
                {
                    resultAnswer = MessageBox.Show("Cats Game! Do you want to play again?", "Game Result",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                }
            }
            if (resultAnswer == DialogResult.Yes)
            {
                //creates new game
                PicBox1.Image = null;
                PicBox2.Image = null;
                PicBox3.Image = null;
                PicBox4.Image = null;
                PicBox5.Image = null;
                PicBox6.Image = null;
                PicBox7.Image = null;
                PicBox8.Image = null;
                PicBox9.Image = null;
                PicBox1.Enabled = true;
                PicBox2.Enabled = true;
                PicBox3.Enabled = true;
                PicBox4.Enabled = true;
                PicBox5.Enabled = true;
                PicBox6.Enabled = true;
                PicBox7.Enabled = true;
                PicBox8.Enabled = true;
                PicBox9.Enabled = true;
                counter = 0;
            }
            else if (resultAnswer == DialogResult.No)
            {
                //closes program
                this.Close();
            }
        
        }
    }
}
