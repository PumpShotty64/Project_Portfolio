﻿namespace SlotMachine
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.picMothership = new System.Windows.Forms.PictureBox();
            this.picImmortal = new System.Windows.Forms.PictureBox();
            this.picProbe = new System.Windows.Forms.PictureBox();
            this.picGasMinerals = new System.Windows.Forms.PictureBox();
            this.picMinerals = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.picSlot3 = new System.Windows.Forms.PictureBox();
            this.picSlot2 = new System.Windows.Forms.PictureBox();
            this.picSlot1 = new System.Windows.Forms.PictureBox();
            this.lblGrandPrize = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblMoney = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtAddMoney = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.rad1 = new System.Windows.Forms.RadioButton();
            this.rad2 = new System.Windows.Forms.RadioButton();
            this.rad3 = new System.Windows.Forms.RadioButton();
            this.rad4 = new System.Windows.Forms.RadioButton();
            this.rad5 = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.picBlank = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picMothership)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picImmortal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picProbe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGasMinerals)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMinerals)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlot3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlot2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlot1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBlank)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.SlateBlue;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Ravie", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(659, 51);
            this.label1.TabIndex = 3;
            this.label1.Text = "StarcraftII Slots";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Yellow;
            this.label2.Font = new System.Drawing.Font("Ravie", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(557, 5);
            this.label2.TabIndex = 4;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Yellow;
            this.label3.Font = new System.Drawing.Font("Ravie", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 258);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(557, 5);
            this.label3.TabIndex = 5;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Yellow;
            this.label4.Font = new System.Drawing.Font("Ravie", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(5, 188);
            this.label4.TabIndex = 6;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Yellow;
            this.label5.Font = new System.Drawing.Font("Ravie", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(555, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(5, 188);
            this.label5.TabIndex = 7;
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picMothership
            // 
            this.picMothership.BackColor = System.Drawing.Color.RoyalBlue;
            this.picMothership.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picMothership.Image = global::SlotMachine.Properties.Resources.Mothership;
            this.picMothership.Location = new System.Drawing.Point(206, 323);
            this.picMothership.Name = "picMothership";
            this.picMothership.Size = new System.Drawing.Size(39, 35);
            this.picMothership.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picMothership.TabIndex = 13;
            this.picMothership.TabStop = false;
            // 
            // picImmortal
            // 
            this.picImmortal.BackColor = System.Drawing.Color.RoyalBlue;
            this.picImmortal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picImmortal.Image = global::SlotMachine.Properties.Resources.Immortal;
            this.picImmortal.Location = new System.Drawing.Point(107, 323);
            this.picImmortal.Name = "picImmortal";
            this.picImmortal.Size = new System.Drawing.Size(39, 35);
            this.picImmortal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picImmortal.TabIndex = 12;
            this.picImmortal.TabStop = false;
            // 
            // picProbe
            // 
            this.picProbe.BackColor = System.Drawing.Color.RoyalBlue;
            this.picProbe.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picProbe.Image = global::SlotMachine.Properties.Resources.Probe1;
            this.picProbe.Location = new System.Drawing.Point(12, 323);
            this.picProbe.Name = "picProbe";
            this.picProbe.Size = new System.Drawing.Size(39, 35);
            this.picProbe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picProbe.TabIndex = 11;
            this.picProbe.TabStop = false;
            // 
            // picGasMinerals
            // 
            this.picGasMinerals.BackColor = System.Drawing.Color.White;
            this.picGasMinerals.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picGasMinerals.Image = global::SlotMachine.Properties.Resources.GasMineral;
            this.picGasMinerals.Location = new System.Drawing.Point(547, 323);
            this.picGasMinerals.Name = "picGasMinerals";
            this.picGasMinerals.Size = new System.Drawing.Size(39, 35);
            this.picGasMinerals.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picGasMinerals.TabIndex = 10;
            this.picGasMinerals.TabStop = false;
            // 
            // picMinerals
            // 
            this.picMinerals.BackColor = System.Drawing.Color.White;
            this.picMinerals.BackgroundImage = global::SlotMachine.Properties.Resources.Probe;
            this.picMinerals.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picMinerals.Image = global::SlotMachine.Properties.Resources.Mineral;
            this.picMinerals.Location = new System.Drawing.Point(299, 323);
            this.picMinerals.Name = "picMinerals";
            this.picMinerals.Size = new System.Drawing.Size(39, 35);
            this.picMinerals.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picMinerals.TabIndex = 9;
            this.picMinerals.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = global::SlotMachine.Properties.Resources.Lever;
            this.pictureBox1.Location = new System.Drawing.Point(566, 83);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(105, 172);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // picSlot3
            // 
            this.picSlot3.BackColor = System.Drawing.Color.RoyalBlue;
            this.picSlot3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picSlot3.Location = new System.Drawing.Point(374, 83);
            this.picSlot3.Name = "picSlot3";
            this.picSlot3.Size = new System.Drawing.Size(175, 172);
            this.picSlot3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSlot3.TabIndex = 2;
            this.picSlot3.TabStop = false;
            // 
            // picSlot2
            // 
            this.picSlot2.BackColor = System.Drawing.Color.RoyalBlue;
            this.picSlot2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picSlot2.Location = new System.Drawing.Point(193, 83);
            this.picSlot2.Name = "picSlot2";
            this.picSlot2.Size = new System.Drawing.Size(175, 172);
            this.picSlot2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSlot2.TabIndex = 1;
            this.picSlot2.TabStop = false;
            // 
            // picSlot1
            // 
            this.picSlot1.BackColor = System.Drawing.Color.RoyalBlue;
            this.picSlot1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picSlot1.Location = new System.Drawing.Point(12, 83);
            this.picSlot1.Name = "picSlot1";
            this.picSlot1.Size = new System.Drawing.Size(175, 172);
            this.picSlot1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSlot1.TabIndex = 0;
            this.picSlot1.TabStop = false;
            // 
            // lblGrandPrize
            // 
            this.lblGrandPrize.BackColor = System.Drawing.Color.White;
            this.lblGrandPrize.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblGrandPrize.Location = new System.Drawing.Point(449, 297);
            this.lblGrandPrize.Name = "lblGrandPrize";
            this.lblGrandPrize.Size = new System.Drawing.Size(105, 20);
            this.lblGrandPrize.TabIndex = 14;
            this.lblGrandPrize.Text = "$1,000.00";
            this.lblGrandPrize.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Aqua;
            this.label6.Location = new System.Drawing.Point(449, 268);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 23);
            this.label6.TabIndex = 15;
            this.label6.Text = "Grand Prize";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMoney
            // 
            this.lblMoney.BackColor = System.Drawing.Color.White;
            this.lblMoney.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblMoney.Location = new System.Drawing.Point(123, 297);
            this.lblMoney.Name = "lblMoney";
            this.lblMoney.Size = new System.Drawing.Size(105, 20);
            this.lblMoney.TabIndex = 16;
            this.lblMoney.Text = "$0.00";
            this.lblMoney.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Aqua;
            this.label10.Location = new System.Drawing.Point(123, 268);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(105, 23);
            this.label10.TabIndex = 17;
            this.label10.Text = "Your Money";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtAddMoney
            // 
            this.txtAddMoney.Location = new System.Drawing.Point(12, 297);
            this.txtAddMoney.Name = "txtAddMoney";
            this.txtAddMoney.Size = new System.Drawing.Size(67, 20);
            this.txtAddMoney.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Aqua;
            this.label8.Location = new System.Drawing.Point(12, 268);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(105, 23);
            this.label8.TabIndex = 19;
            this.label8.Text = "Add Money";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rad1
            // 
            this.rad1.AutoSize = true;
            this.rad1.Checked = true;
            this.rad1.ForeColor = System.Drawing.Color.Aqua;
            this.rad1.Location = new System.Drawing.Point(234, 299);
            this.rad1.Name = "rad1";
            this.rad1.Size = new System.Drawing.Size(37, 17);
            this.rad1.TabIndex = 20;
            this.rad1.TabStop = true;
            this.rad1.Text = "$1";
            this.rad1.UseVisualStyleBackColor = true;
            // 
            // rad2
            // 
            this.rad2.AutoSize = true;
            this.rad2.ForeColor = System.Drawing.Color.Aqua;
            this.rad2.Location = new System.Drawing.Point(277, 299);
            this.rad2.Name = "rad2";
            this.rad2.Size = new System.Drawing.Size(37, 17);
            this.rad2.TabIndex = 21;
            this.rad2.Text = "$2";
            this.rad2.UseVisualStyleBackColor = true;
            // 
            // rad3
            // 
            this.rad3.AutoSize = true;
            this.rad3.ForeColor = System.Drawing.Color.Aqua;
            this.rad3.Location = new System.Drawing.Point(320, 299);
            this.rad3.Name = "rad3";
            this.rad3.Size = new System.Drawing.Size(37, 17);
            this.rad3.TabIndex = 22;
            this.rad3.Text = "$3";
            this.rad3.UseVisualStyleBackColor = true;
            // 
            // rad4
            // 
            this.rad4.AutoSize = true;
            this.rad4.ForeColor = System.Drawing.Color.Aqua;
            this.rad4.Location = new System.Drawing.Point(363, 299);
            this.rad4.Name = "rad4";
            this.rad4.Size = new System.Drawing.Size(37, 17);
            this.rad4.TabIndex = 23;
            this.rad4.Text = "$4";
            this.rad4.UseVisualStyleBackColor = true;
            // 
            // rad5
            // 
            this.rad5.AutoSize = true;
            this.rad5.ForeColor = System.Drawing.Color.Aqua;
            this.rad5.Location = new System.Drawing.Point(406, 299);
            this.rad5.Name = "rad5";
            this.rad5.Size = new System.Drawing.Size(37, 17);
            this.rad5.TabIndex = 24;
            this.rad5.Text = "$5";
            this.rad5.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Aqua;
            this.label7.Location = new System.Drawing.Point(234, 268);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(209, 23);
            this.label7.TabIndex = 25;
            this.label7.Text = "Bets";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Yellow;
            this.label9.Location = new System.Drawing.Point(566, 268);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 49);
            this.label9.TabIndex = 26;
            this.label9.Text = "Pull the Lever!";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(80, 296);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(38, 23);
            this.btnAdd.TabIndex = 28;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.BackgroundImage = global::SlotMachine.Properties.Resources.Probe;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Image = global::SlotMachine.Properties.Resources.Mineral;
            this.pictureBox2.Location = new System.Drawing.Point(397, 323);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(39, 35);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 29;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Image = global::SlotMachine.Properties.Resources.GasMineral;
            this.pictureBox3.Location = new System.Drawing.Point(459, 323);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(39, 35);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 30;
            this.pictureBox3.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Lime;
            this.label11.Location = new System.Drawing.Point(579, 67);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 13);
            this.label11.TabIndex = 27;
            this.label11.Text = "Jordan Nguyen";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Lime;
            this.label12.Location = new System.Drawing.Point(57, 333);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 13);
            this.label12.TabIndex = 31;
            this.label12.Text = "= $10";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Lime;
            this.label13.Location = new System.Drawing.Point(152, 333);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 13);
            this.label13.TabIndex = 32;
            this.label13.Text = "= $15";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Lime;
            this.label14.Location = new System.Drawing.Point(344, 333);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 13);
            this.label14.TabIndex = 33;
            this.label14.Text = "= $100";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Lime;
            this.label15.Location = new System.Drawing.Point(251, 333);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(34, 13);
            this.label15.TabIndex = 34;
            this.label15.Text = "= $25";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Lime;
            this.label16.Location = new System.Drawing.Point(441, 333);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(13, 13);
            this.label16.TabIndex = 35;
            this.label16.Text = "+";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Lime;
            this.label17.Location = new System.Drawing.Point(503, 333);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(34, 13);
            this.label17.TabIndex = 36;
            this.label17.Text = "= $50";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Lime;
            this.label18.Location = new System.Drawing.Point(592, 333);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 13);
            this.label18.TabIndex = 37;
            this.label18.Text = "= Grand Prize";
            // 
            // picBlank
            // 
            this.picBlank.BackColor = System.Drawing.Color.RoyalBlue;
            this.picBlank.Location = new System.Drawing.Point(12, 83);
            this.picBlank.Name = "picBlank";
            this.picBlank.Size = new System.Drawing.Size(39, 35);
            this.picBlank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBlank.TabIndex = 38;
            this.picBlank.TabStop = false;
            this.picBlank.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(683, 364);
            this.Controls.Add(this.picBlank);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.rad5);
            this.Controls.Add(this.rad4);
            this.Controls.Add(this.rad3);
            this.Controls.Add(this.rad2);
            this.Controls.Add(this.rad1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtAddMoney);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lblMoney);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblGrandPrize);
            this.Controls.Add(this.picMothership);
            this.Controls.Add(this.picImmortal);
            this.Controls.Add(this.picProbe);
            this.Controls.Add(this.picGasMinerals);
            this.Controls.Add(this.picMinerals);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picSlot3);
            this.Controls.Add(this.picSlot2);
            this.Controls.Add(this.picSlot1);
            this.Name = "Form1";
            this.Text = "Slot Machine";
            ((System.ComponentModel.ISupportInitialize)(this.picMothership)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picImmortal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picProbe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGasMinerals)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMinerals)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlot3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlot2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlot1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBlank)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picSlot1;
        private System.Windows.Forms.PictureBox picSlot2;
        private System.Windows.Forms.PictureBox picSlot3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox picMinerals;
        private System.Windows.Forms.PictureBox picGasMinerals;
        private System.Windows.Forms.PictureBox picProbe;
        private System.Windows.Forms.PictureBox picImmortal;
        private System.Windows.Forms.PictureBox picMothership;
        private System.Windows.Forms.Label lblGrandPrize;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblMoney;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtAddMoney;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton rad1;
        private System.Windows.Forms.RadioButton rad2;
        private System.Windows.Forms.RadioButton rad3;
        private System.Windows.Forms.RadioButton rad4;
        private System.Windows.Forms.RadioButton rad5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox picBlank;
    }
}

