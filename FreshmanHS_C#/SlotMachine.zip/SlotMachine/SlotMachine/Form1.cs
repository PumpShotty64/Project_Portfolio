﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Jordan Nguyen
//Period 0
//12/5/14
/*The project consist of three random number generator that allow the user to play slots
 almost exactly like how it is done in the casino.*/



namespace SlotMachine
{
    public partial class Form1 : Form
    {
        //declare global variables
        private decimal MoneyDecimal = 0m;
        private decimal BetDecimal;
        private decimal GrandTotalDecimal = 1000m;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //declare variables
            decimal ProbeDecimal = 10m;
            decimal ImmortalDecimal = 15m;
            decimal MothershipDecimal = 25m;
            decimal MineralsDecimal = 100m;
            decimal MineralGasDecimal = 50m;

            //creates a random number generator
            System.Random r = new System.Random((int)System.DateTime.Now.Ticks);
            int myRandom = r.Next(1, 12);
            int myRandom2 = r.Next(1, 12);
            int myRandom3 = r.Next(1, 12);

            //outputs the images in a function
            picSlot1.Image = selectPic(myRandom);
            picSlot2.Image = selectPic(myRandom2);
            picSlot3.Image = selectPic(myRandom3);
            
            //sets the value of the bets
            if(rad1.Checked)
            {
                BetDecimal = 1m;
            }
            else if (rad2.Checked)
            {
                BetDecimal = 2m;
            }
            else if (rad3.Checked)
            {
                BetDecimal = 3m;
            }
            else if (rad4.Checked)
            {
                BetDecimal = 4m;
            }
            else if (rad5.Checked)
            {
                BetDecimal = 5m;
            }

            //calculations
            if (picSlot1.Image == picProbe.Image && picSlot2.Image == picProbe.Image 
                && picSlot3.Image == picProbe.Image)
            {
                MoneyDecimal += ProbeDecimal * BetDecimal;
                GrandTotalDecimal += BetDecimal;
            }
            else if (picSlot1.Image == picImmortal.Image && picSlot2.Image == picImmortal.Image
                && picSlot3.Image == picImmortal.Image)
            {
                MoneyDecimal += ImmortalDecimal * BetDecimal;
                GrandTotalDecimal += BetDecimal;
            }
            else if (picSlot1.Image == picMothership.Image && picSlot2.Image == picMothership.Image
                && picSlot3.Image == picMothership.Image)
            {
                MoneyDecimal += MothershipDecimal * BetDecimal;
                GrandTotalDecimal += BetDecimal;
            }
            else if (picSlot1.Image == picMinerals.Image && picSlot2.Image == picMinerals.Image
                && picSlot3.Image == picMinerals.Image)
            {
                MoneyDecimal += MineralsDecimal * BetDecimal;
                GrandTotalDecimal += BetDecimal;
            }
            else if (picSlot1.Image == picMinerals.Image && picSlot2.Image == picGasMinerals.Image
                && picSlot3.Image == picMinerals.Image)
            {
                MoneyDecimal += MineralGasDecimal * BetDecimal;
                GrandTotalDecimal += BetDecimal;
            }
            else if (picSlot1.Image == picMinerals.Image && picSlot2.Image == picMinerals.Image
                && picSlot3.Image == picGasMinerals.Image)
            {
                MoneyDecimal += MineralGasDecimal * BetDecimal;
                GrandTotalDecimal += BetDecimal;
            }
            else if (picSlot1.Image == picGasMinerals.Image && picSlot2.Image == picMinerals.Image
                && picSlot3.Image == picMinerals.Image)
            {
                MoneyDecimal += MineralGasDecimal * BetDecimal;
                GrandTotalDecimal += BetDecimal;
            }
            else if (picSlot1.Image == picGasMinerals.Image && picSlot2.Image == picGasMinerals.Image
                && picSlot3.Image == picMinerals.Image)
            {
                MoneyDecimal += MineralGasDecimal * BetDecimal;
                GrandTotalDecimal += BetDecimal;
            }
            else if (picSlot1.Image == picGasMinerals.Image && picSlot2.Image == picMinerals.Image
                && picSlot3.Image == picGasMinerals.Image)
            {
                MoneyDecimal += MineralGasDecimal * BetDecimal;
                GrandTotalDecimal += BetDecimal;
            }
            else if (picSlot1.Image == picMinerals.Image && picSlot2.Image == picGasMinerals.Image
                && picSlot3.Image == picGasMinerals.Image)
            {
                MoneyDecimal += MineralGasDecimal * BetDecimal;
                GrandTotalDecimal += BetDecimal;
            }
            else if (picSlot1.Image == picGasMinerals.Image && picSlot2.Image == picGasMinerals.Image
                && picSlot3.Image == picGasMinerals.Image)
            {
                MoneyDecimal += GrandTotalDecimal;
                GrandTotalDecimal = 1000m;
            }
            else if (MoneyDecimal <= 0)
            {
                picSlot1.Image = picBlank.Image;
                picSlot2.Image = picBlank.Image;
                picSlot3.Image = picBlank.Image;
                MessageBox.Show("You need to insert more credits!", "Insufficient Credits",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (MoneyDecimal <= 1 && rad2.Checked)
            {
                picSlot1.Image = picBlank.Image;
                picSlot2.Image = picBlank.Image;
                picSlot3.Image = picBlank.Image;
                MessageBox.Show("You need to insert more credits!", "Insufficient Credits",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (MoneyDecimal <= 2 && rad3.Checked)
            {
                picSlot1.Image = picBlank.Image;
                picSlot2.Image = picBlank.Image;
                picSlot3.Image = picBlank.Image;
                MessageBox.Show("You need to insert more credits!", "Insufficient Credits",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (MoneyDecimal <= 3 && rad4.Checked)
            {
                picSlot1.Image = picBlank.Image;
                picSlot2.Image = picBlank.Image;
                picSlot3.Image = picBlank.Image;
                MessageBox.Show("You need to insert more credits!", "Insufficient Credits",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (MoneyDecimal <= 4 && rad5.Checked)
            {
                picSlot1.Image = picBlank.Image;
                picSlot2.Image = picBlank.Image;
                picSlot3.Image = picBlank.Image;
                MessageBox.Show("You need to insert more credits!", "Insufficient Credits",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else 
            {
                MoneyDecimal -= BetDecimal;
                GrandTotalDecimal += BetDecimal;
            }

            //outputs the answers
            lblMoney.Text = MoneyDecimal.ToString("C");
            lblGrandPrize.Text = GrandTotalDecimal.ToString("C");
        }

        //creates a function for images
        private Image selectPic(int theNumber) 
        {

            Image thePic = null;

            if (theNumber == 1)
            {
                thePic = picMinerals.Image;
            }
            else if (theNumber == 2)
            {
                thePic = picGasMinerals.Image;
            }
            else if (theNumber == 3)
            {
                thePic = picProbe.Image;
            }
            else if (theNumber == 4)
            {
                thePic = picImmortal.Image;
            }
            else if (theNumber == 5)
            {
                thePic = picMothership.Image;
            }
            else if (theNumber == 6)
            {
                thePic = picProbe.Image;
            }
            else if (theNumber == 7)
            {
                thePic = picImmortal.Image;
            }
            else if (theNumber == 8)
            {
                thePic = picMothership.Image;
            }
            else if (theNumber == 9)
            {
                thePic = picProbe.Image;
            }
            else if (theNumber == 10)
            {
                thePic = picProbe.Image;
            }
            else if (theNumber == 11)
            {
                thePic = picImmortal.Image;
            }
            return thePic;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //declares a variable
            decimal AddMoneyDecimal;
            
            //prevents the program crashes
            try
            {
                
            //takes users information from textbox
            AddMoneyDecimal = Decimal.Parse(txtAddMoney.Text);

            //calculations
            MoneyDecimal += AddMoneyDecimal;
            //outputs answers
            lblMoney.Text = MoneyDecimal.ToString("C");
            AddMoneyDecimal = 0;
            txtAddMoney.Text = "";

            }
            catch
            {
                MessageBox.Show("You need to input number!", "No Deposit",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddMoney.Text = "";
            }
        }
    }
}
