﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tanks
{
    //Jordan Nguyen
    //Period 0
    //4//11/2015
    //This is a simulation of tanks where the user controls a tank to destroy the enemy
    public partial class frmMain : Form
    {
        int bulletDirection = 0;
        //gives health to enemy
        int Health = 3;

        public frmMain()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //closes the program
            this.Close();
        }

        private void frmMain_KeyDown(object sender, KeyEventArgs e)
        {
            int whichkey = e.KeyValue;
            //allows user to choose yes or no in message box
            DialogResult resultAnswer = DialogResult;
            //sets a hitbox for the bullet and tank
            Rectangle enemyBox = new Rectangle(picEnemyBlank.Left, picEnemyBlank.Top, picEnemyBlank.Width, picEnemyBlank.Height);
            Rectangle TankBox = new Rectangle(picTankBlank.Left, picTankBlank.Top, picTankBlank.Width, picTankBlank.Height);

            //moves tank and bullet
            if (whichkey == 37)
            {
                timerL.Enabled = true;
                picTankBlank.Image = picTankYouL.Image;
                if(bullettimer.Enabled == false)
                {
                    bulletDirection = 37;
                }
            }
            else if (whichkey == 39)
            {
                timerR.Enabled = true;
                picTankBlank.Image = picTankYouR.Image;
                if (bullettimer.Enabled == false)
                {
                    bulletDirection = 39;
                }
            }
            else if (whichkey == 38)
            {
                timerU.Enabled = true;
                picTankBlank.Image = picTankYouU.Image;
                if (bullettimer.Enabled == false)
                {
                    bulletDirection = 38;
                }
            }
            else if (whichkey == 40)
            {
                timerD.Enabled = true;
                picTankBlank.Image = picTankYouD.Image;
                if (bullettimer.Enabled == false)
                {
                    bulletDirection = 40;
                }
            }
            //recalls the bullet to the tank
            if (picTankBlank.Image == picTankYouU.Image && bullettimer.Enabled == false)
            {
                lblBullet.Left = lblMiddleU.Left;
                lblBullet.Top = lblMiddleU.Top;
            }
            else if (picTankBlank.Image == picTankYouD.Image && bullettimer.Enabled == false)
            {
                lblBullet.Left = lblMiddleD.Left;
                lblBullet.Top = lblMiddleD.Top;
                
            }
            else if (picTankBlank.Image == picTankYouL.Image && bullettimer.Enabled == false)
            {
                lblBullet.Left = lblMiddleL.Left;
                lblBullet.Top = lblMiddleL.Top;
                
            }
            else if (picTankBlank.Image == picTankYouR.Image && bullettimer.Enabled == false)
            {
                lblBullet.Left = lblMiddleR.Left;
                lblBullet.Top = lblMiddleR.Top;
                
            }
            //allows user to fire bullet
            if (whichkey == 32)
            {
                lblBullet.Visible = true;
                bullettimer.Enabled = true;
            }
            if (bullettimer.Enabled == false)
            {
                lblBullet.Left = lblMiddleU.Left;
                lblBullet.Top = lblMiddleU.Top;
            }
            //New game message box if lose
            if (TankBox.IntersectsWith(enemyBox))
            {
                resultAnswer = MessageBox.Show("Mission Failed! Do you want to start a new game?", "New Game",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (resultAnswer == DialogResult.Yes)
                {
                    picTankBlank.Location = new Point(815, 398);
                    picEnemyBlank.Visible = true;
                    picEnemyBlank.Location = new Point(12, 35);
                    lblBullet.Location = new Point(851, 398);
                    lblMiddleU.Location = new Point(851, 398);
                    lblMiddleL.Location = new Point(816, 434);
                    lblMiddleR.Location = new Point(880, 434);
                    lblMiddleD.Location = new Point(851, 463);
                    Health = 3;
                }
                else if (resultAnswer == DialogResult.No)
                {
                    this.Close();
                }
            }
        }

        private void frmMain_KeyUp(object sender, KeyEventArgs e)
        {
            //variable for key value
            int whichkey = e.KeyValue;

            //movement for the tank
            if (whichkey == 37)
            {
                timerL.Enabled = false;
            }
            else if (whichkey == 39)
            {
                timerR.Enabled = false;
            }
            else if (whichkey == 38)
            {
                timerU.Enabled = false;
            }
            else if (whichkey == 40)
            {
                timerD.Enabled = false;
            }
        }

        private void timerL_Tick(object sender, EventArgs e)
        {
            //moves the tank left
            if (picTankBlank.Left >= 10)
            {
                picTankBlank.Left -= 10;
                lblMiddleL.Left -= 10;
                lblMiddleR.Left -= 10;
                lblMiddleU.Left -= 10;
                lblMiddleD.Left -= 10;
            }
            //prevents tank from moving through barrier
            if (picTankBlank.Left <= barrier1.Right && picTankBlank.Right >= barrier1.Right && picTankBlank.Bottom >= barrier1.Top)
            {
                picTankBlank.Left += 10;
                lblMiddleL.Left += 10;
                lblMiddleR.Left += 10;
                lblMiddleU.Left += 10;
                lblMiddleD.Left += 10;
            }
            if (picTankBlank.Left <= barrier2.Right && picTankBlank.Right >= barrier2.Right && picTankBlank.Top <= barrier2.Bottom)
            {
                picTankBlank.Left += 10;
                lblMiddleL.Left += 10;
                lblMiddleR.Left += 10;
                lblMiddleU.Left += 10;
                lblMiddleD.Left += 10;
            }
        }

        private void timerR_Tick(object sender, EventArgs e)
        {
            //moves the tank right
            if (picTankBlank.Right <= this.Width - 25)
            {
                picTankBlank.Left += 10;
                lblMiddleR.Left += 10;
                lblMiddleL.Left += 10;
                lblMiddleU.Left += 10;
                lblMiddleD.Left += 10;
            }
            //prevents tank from moving through barrier
            if (picTankBlank.Left <= barrier1.Left && picTankBlank.Right >= barrier1.Left && picTankBlank.Bottom >= barrier1.Top)
            {
                picTankBlank.Left -= 10;
                lblMiddleL.Left -= 10;
                lblMiddleR.Left -= 10;
                lblMiddleU.Left -= 10;
                lblMiddleD.Left -= 10;
            }
            if (picTankBlank.Left <= barrier2.Left && picTankBlank.Right >= barrier2.Left && picTankBlank.Top <= barrier2.Bottom)
            {
                picTankBlank.Left -= 10;
                lblMiddleL.Left -= 10;
                lblMiddleR.Left -= 10;
                lblMiddleU.Left -= 10;
                lblMiddleD.Left -= 10;
            }
        }

        private void timerU_Tick(object sender, EventArgs e)
        {
            //moves the tank up
            if (picTankBlank.Top >= 29)
            {
                picTankBlank.Top -= 10;
                lblMiddleU.Top -= 10;
                lblMiddleD.Top -= 10;
                lblMiddleL.Top -= 10;
                lblMiddleR.Top -= 10;
            }
            //prevents tank from moving through barrier
            if (picTankBlank.Left <= barrier2.Right && picTankBlank.Right >= barrier2.Left && picTankBlank.Top <= barrier2.Bottom)
            {
                picTankBlank.Top += 10;
                lblMiddleL.Top += 10;
                lblMiddleR.Top += 10;
                lblMiddleU.Top += 10;
                lblMiddleD.Top += 10;
            }
        }

        private void timerD_Tick(object sender, EventArgs e)
        {
            //moves the tank down
            if (picTankBlank.Bottom <= this.Height - 50)
            {
                picTankBlank.Top += 10;
                lblMiddleD.Top += 10;
                lblMiddleU.Top += 10;
                lblMiddleL.Top += 10;
                lblMiddleR.Top += 10;
            }
            //prevents tank from moving through barrier
            if (picTankBlank.Left <= barrier1.Right && picTankBlank.Right >= barrier1.Left && picTankBlank.Bottom >= barrier1.Top)
            {
                picTankBlank.Top -= 10;
                lblMiddleL.Top -= 10;
                lblMiddleR.Top -= 10;
                lblMiddleU.Top -= 10;
                lblMiddleD.Top -= 10;
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void bullettimer_Tick(object sender, EventArgs e)
        {
            //sets a hitbox for the bullet and tank
            Rectangle bulletBox = new Rectangle(lblBullet.Left, lblBullet.Top, lblBullet.Width, lblBullet.Height);
            Rectangle enemyBox = new Rectangle(picEnemyBlank.Left, picEnemyBlank.Top, picEnemyBlank.Width, picEnemyBlank.Height);
            Rectangle TankBox = new Rectangle(picTankBlank.Left, picTankBlank.Top, picTankBlank.Width, picTankBlank.Height);
            //allows user to choose yes or no in message box
            DialogResult resultAnswer = DialogResult;

            //sets variables for movement of bullet
            int bullety = lblBullet.Top;
            int bulletx = lblBullet.Left;

            //allows bullet to move
            if (bulletDirection == 38)
            {
                lblBullet.Size = new Size(4, 10);
                bullety -= 5;
            }
            else if (bulletDirection == 40)
            {
                lblBullet.Size = new Size(4, 10);
                bullety += 5;
            }
            else if (bulletDirection == 37)
            {
                lblBullet.Size = new Size(10, 4);
                bulletx -= 5;
            }
            else if (bulletDirection == 39)
            {
                lblBullet.Size = new Size(10, 4);
                bulletx += 5;
            }
            lblBullet.Top = bullety;
            lblBullet.Left = bulletx;

            //recalls bullet back to the tank
            if (lblBullet.Top < 10)
            {
                bullettimer.Enabled = false;
                lblBullet.Visible = false;
                if (picTankBlank.Image == picTankYouU.Image)
                {
                    lblBullet.Left = lblMiddleU.Left;
                    lblBullet.Top = lblMiddleU.Top;
                }
                else if (picTankBlank.Image == picTankYouD.Image)
                {
                    lblBullet.Left = lblMiddleD.Left;
                    lblBullet.Top = lblMiddleD.Top;
                }
                else if (picTankBlank.Image == picTankYouL.Image)
                {
                    lblBullet.Left = lblMiddleL.Left;
                    lblBullet.Top = lblMiddleL.Top;
                }
                else if (picTankBlank.Image == picTankYouR.Image)
                {
                    lblBullet.Left = lblMiddleR.Left;
                    lblBullet.Top = lblMiddleR.Top;
                }
            }
            else if (lblBullet.Left < -10)
            {
                bullettimer.Enabled = false;
                lblBullet.Visible = false;
                if (picTankBlank.Image == picTankYouU.Image)
                {
                    lblBullet.Left = lblMiddleU.Left;
                    lblBullet.Top = lblMiddleU.Top;
                }
                else if (picTankBlank.Image == picTankYouD.Image)
                {
                    lblBullet.Left = lblMiddleD.Left;
                    lblBullet.Top = lblMiddleD.Top;
                }
                else if (picTankBlank.Image == picTankYouL.Image)
                {
                    lblBullet.Left = lblMiddleL.Left;
                    lblBullet.Top = lblMiddleL.Top;
                }
                else if (picTankBlank.Image == picTankYouR.Image)
                {
                    lblBullet.Left = lblMiddleR.Left;
                    lblBullet.Top = lblMiddleR.Top;
                }
            }
            else if (lblBullet.Right > this.Width)
            {
                bullettimer.Enabled = false;
                lblBullet.Visible = false;
                if (picTankBlank.Image == picTankYouU.Image)
                {
                    lblBullet.Left = lblMiddleU.Left;
                    lblBullet.Top = lblMiddleU.Top;
                }
                else if (picTankBlank.Image == picTankYouD.Image)
                {
                    lblBullet.Left = lblMiddleD.Left;
                    lblBullet.Top = lblMiddleD.Top;
                }
                else if (picTankBlank.Image == picTankYouL.Image)
                {
                    lblBullet.Left = lblMiddleL.Left;
                    lblBullet.Top = lblMiddleL.Top;
                }
                else if (picTankBlank.Image == picTankYouR.Image)
                {
                    lblBullet.Left = lblMiddleR.Left;
                    lblBullet.Top = lblMiddleR.Top;
                }
            }
            else if (lblBullet.Bottom > this.Height)
            {
                bullettimer.Enabled = false;
                lblBullet.Visible = false;
                if (picTankBlank.Image == picTankYouU.Image)
                {
                    lblBullet.Left = lblMiddleU.Left;
                    lblBullet.Top = lblMiddleU.Top;
                }
                else if (picTankBlank.Image == picTankYouD.Image)
                {
                    lblBullet.Left = lblMiddleD.Left;
                    lblBullet.Top = lblMiddleD.Top;
                }
                else if (picTankBlank.Image == picTankYouL.Image)
                {
                    lblBullet.Left = lblMiddleL.Left;
                    lblBullet.Top = lblMiddleL.Top;
                }
                else if (picTankBlank.Image == picTankYouR.Image)
                {
                    lblBullet.Left = lblMiddleR.Left;
                    lblBullet.Top = lblMiddleR.Top;
                }
            }
            //allows bullet to return your tank and deal damage to enemy tank
             if (bulletBox.IntersectsWith(enemyBox))
            {
                bullettimer.Enabled = false;
                lblBullet.Visible = false;
                //subtracts health from enemy
                Health -= 1;

                if (picTankBlank.Image == picTankYouU.Image)
                {
                    lblBullet.Left = lblMiddleU.Left;
                    lblBullet.Top = lblMiddleU.Top;
                }
                else if (picTankBlank.Image == picTankYouD.Image)
                {
                    lblBullet.Left = lblMiddleD.Left;
                    lblBullet.Top = lblMiddleD.Top;
                }
                else if (picTankBlank.Image == picTankYouL.Image)
                {
                    lblBullet.Left = lblMiddleL.Left;
                    lblBullet.Top = lblMiddleL.Top;
                }
                else if (picTankBlank.Image == picTankYouR.Image)
                {
                    lblBullet.Left = lblMiddleR.Left;
                    lblBullet.Top = lblMiddleR.Top;
                }
             }
             //kills the tank
             if (Health <= 0)
             {
                 picEnemyBlank.Visible = false;
             }
            //New game message box if win
             if (picEnemyBlank.Visible == false)
             {
                 resultAnswer = MessageBox.Show("Mission Accomplished! Do you want to start a new game?", "New Game",
                             MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                 if (resultAnswer == DialogResult.Yes)
                 {
                     picTankBlank.Location = new Point(815, 398);
                     picEnemyBlank.Visible = true;
                     picEnemyBlank.Location = new Point(12, 35);
                     lblBullet.Location = new Point(851, 398);
                     lblMiddleU.Location = new Point(851, 398);
                     lblMiddleL.Location = new Point(816, 434);
                     lblMiddleR.Location = new Point(880, 434);
                     lblMiddleD.Location = new Point(851, 463);
                     Health = 3;
                 }
                 else if (resultAnswer == DialogResult.No)
                 {
                     this.Close();
                 }
             }
        }

        private void picTankBlank_Click(object sender, EventArgs e)
        {

        }

        private void picEnemyBlank_Click(object sender, EventArgs e)
        {

        }

        private void EnemyTimer_Tick(object sender, EventArgs e)
        {
            //allows tank to move by its own
            if (picEnemyBlank.Location.X != picTankBlank.Location.X)
            {
                if (picEnemyBlank.Left <= picTankBlank.Left)
                {
                    picEnemyBlank.Left += 5;
                }
                else if (picEnemyBlank.Left >= picTankBlank.Left)
                {
                    picEnemyBlank.Left -= 5;
                }
            }
            if (picEnemyBlank.Location.Y != picTankBlank.Location.Y)
            {
                if (picEnemyBlank.Top <= picTankBlank.Top)
                {
                    picEnemyBlank.Top += 5;
                }
                else if (picEnemyBlank.Top >= picTankBlank.Top)
                {
                    picEnemyBlank.Top -= 5;
                }
            }
        }

    }
}
