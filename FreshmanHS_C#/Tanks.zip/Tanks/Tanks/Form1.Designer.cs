﻿namespace Tanks
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timerL = new System.Windows.Forms.Timer(this.components);
            this.timerR = new System.Windows.Forms.Timer(this.components);
            this.timerU = new System.Windows.Forms.Timer(this.components);
            this.timerD = new System.Windows.Forms.Timer(this.components);
            this.lblBullet = new System.Windows.Forms.Label();
            this.lblMiddleD = new System.Windows.Forms.Label();
            this.lblMiddleR = new System.Windows.Forms.Label();
            this.lblMiddleL = new System.Windows.Forms.Label();
            this.bullettimer = new System.Windows.Forms.Timer(this.components);
            this.lblMiddleU = new System.Windows.Forms.Label();
            this.barrier1 = new System.Windows.Forms.Label();
            this.barrier2 = new System.Windows.Forms.Label();
            this.EnemyTimer = new System.Windows.Forms.Timer(this.components);
            this.picEnemyBlank = new System.Windows.Forms.PictureBox();
            this.picTankYouU = new System.Windows.Forms.PictureBox();
            this.picTankYouD = new System.Windows.Forms.PictureBox();
            this.picTankYouR = new System.Windows.Forms.PictureBox();
            this.picTankYouL = new System.Windows.Forms.PictureBox();
            this.picTankBlank = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picEnemyBlank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTankYouU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTankYouD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTankYouR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTankYouL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTankBlank)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gameToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(902, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // gameToolStripMenuItem
            // 
            this.gameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.gameToolStripMenuItem.Name = "gameToolStripMenuItem";
            this.gameToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.gameToolStripMenuItem.Text = "Game";
            // 
            // newGameToolStripMenuItem
            // 
            this.newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            this.newGameToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.newGameToolStripMenuItem.Text = "New Game";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // timerL
            // 
            this.timerL.Interval = 50;
            this.timerL.Tick += new System.EventHandler(this.timerL_Tick);
            // 
            // timerR
            // 
            this.timerR.Interval = 50;
            this.timerR.Tick += new System.EventHandler(this.timerR_Tick);
            // 
            // timerU
            // 
            this.timerU.Interval = 50;
            this.timerU.Tick += new System.EventHandler(this.timerU_Tick);
            // 
            // timerD
            // 
            this.timerD.Interval = 50;
            this.timerD.Tick += new System.EventHandler(this.timerD_Tick);
            // 
            // lblBullet
            // 
            this.lblBullet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblBullet.Location = new System.Drawing.Point(851, 398);
            this.lblBullet.Name = "lblBullet";
            this.lblBullet.Size = new System.Drawing.Size(4, 10);
            this.lblBullet.TabIndex = 6;
            this.lblBullet.Visible = false;
            // 
            // lblMiddleD
            // 
            this.lblMiddleD.BackColor = System.Drawing.Color.White;
            this.lblMiddleD.Location = new System.Drawing.Point(851, 463);
            this.lblMiddleD.Name = "lblMiddleD";
            this.lblMiddleD.Size = new System.Drawing.Size(4, 10);
            this.lblMiddleD.TabIndex = 7;
            this.lblMiddleD.Visible = false;
            // 
            // lblMiddleR
            // 
            this.lblMiddleR.BackColor = System.Drawing.Color.White;
            this.lblMiddleR.Location = new System.Drawing.Point(880, 434);
            this.lblMiddleR.Name = "lblMiddleR";
            this.lblMiddleR.Size = new System.Drawing.Size(10, 4);
            this.lblMiddleR.TabIndex = 8;
            this.lblMiddleR.Visible = false;
            // 
            // lblMiddleL
            // 
            this.lblMiddleL.BackColor = System.Drawing.Color.White;
            this.lblMiddleL.Location = new System.Drawing.Point(816, 434);
            this.lblMiddleL.Name = "lblMiddleL";
            this.lblMiddleL.Size = new System.Drawing.Size(10, 4);
            this.lblMiddleL.TabIndex = 9;
            this.lblMiddleL.Visible = false;
            // 
            // bullettimer
            // 
            this.bullettimer.Interval = 10;
            this.bullettimer.Tick += new System.EventHandler(this.bullettimer_Tick);
            // 
            // lblMiddleU
            // 
            this.lblMiddleU.BackColor = System.Drawing.Color.White;
            this.lblMiddleU.Location = new System.Drawing.Point(851, 398);
            this.lblMiddleU.Name = "lblMiddleU";
            this.lblMiddleU.Size = new System.Drawing.Size(4, 10);
            this.lblMiddleU.TabIndex = 10;
            this.lblMiddleU.Visible = false;
            // 
            // barrier1
            // 
            this.barrier1.BackColor = System.Drawing.Color.Gray;
            this.barrier1.Location = new System.Drawing.Point(344, 350);
            this.barrier1.Name = "barrier1";
            this.barrier1.Size = new System.Drawing.Size(200, 135);
            this.barrier1.TabIndex = 12;
            // 
            // barrier2
            // 
            this.barrier2.BackColor = System.Drawing.Color.Gray;
            this.barrier2.Location = new System.Drawing.Point(344, 24);
            this.barrier2.Name = "barrier2";
            this.barrier2.Size = new System.Drawing.Size(200, 135);
            this.barrier2.TabIndex = 13;
            // 
            // EnemyTimer
            // 
            this.EnemyTimer.Enabled = true;
            this.EnemyTimer.Tick += new System.EventHandler(this.EnemyTimer_Tick);
            // 
            // picEnemyBlank
            // 
            this.picEnemyBlank.Image = global::Tanks.Properties.Resources.Tan_Tank_Right;
            this.picEnemyBlank.Location = new System.Drawing.Point(12, 35);
            this.picEnemyBlank.Name = "picEnemyBlank";
            this.picEnemyBlank.Size = new System.Drawing.Size(75, 75);
            this.picEnemyBlank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEnemyBlank.TabIndex = 11;
            this.picEnemyBlank.TabStop = false;
            this.picEnemyBlank.Click += new System.EventHandler(this.picEnemyBlank_Click);
            // 
            // picTankYouU
            // 
            this.picTankYouU.BackColor = System.Drawing.Color.White;
            this.picTankYouU.Image = global::Tanks.Properties.Resources.Green_Tank;
            this.picTankYouU.Location = new System.Drawing.Point(184, 0);
            this.picTankYouU.Name = "picTankYouU";
            this.picTankYouU.Size = new System.Drawing.Size(31, 29);
            this.picTankYouU.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picTankYouU.TabIndex = 5;
            this.picTankYouU.TabStop = false;
            this.picTankYouU.Visible = false;
            // 
            // picTankYouD
            // 
            this.picTankYouD.BackColor = System.Drawing.Color.White;
            this.picTankYouD.Image = global::Tanks.Properties.Resources.Green_Tank_Down;
            this.picTankYouD.Location = new System.Drawing.Point(147, 0);
            this.picTankYouD.Name = "picTankYouD";
            this.picTankYouD.Size = new System.Drawing.Size(31, 29);
            this.picTankYouD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picTankYouD.TabIndex = 4;
            this.picTankYouD.TabStop = false;
            this.picTankYouD.Visible = false;
            // 
            // picTankYouR
            // 
            this.picTankYouR.BackColor = System.Drawing.Color.White;
            this.picTankYouR.Image = global::Tanks.Properties.Resources.Green_Tank_Right;
            this.picTankYouR.Location = new System.Drawing.Point(110, 0);
            this.picTankYouR.Name = "picTankYouR";
            this.picTankYouR.Size = new System.Drawing.Size(31, 29);
            this.picTankYouR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picTankYouR.TabIndex = 3;
            this.picTankYouR.TabStop = false;
            this.picTankYouR.Visible = false;
            // 
            // picTankYouL
            // 
            this.picTankYouL.BackColor = System.Drawing.Color.White;
            this.picTankYouL.Image = global::Tanks.Properties.Resources.Green_Tank_Left;
            this.picTankYouL.Location = new System.Drawing.Point(73, 0);
            this.picTankYouL.Name = "picTankYouL";
            this.picTankYouL.Size = new System.Drawing.Size(31, 29);
            this.picTankYouL.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picTankYouL.TabIndex = 2;
            this.picTankYouL.TabStop = false;
            this.picTankYouL.Visible = false;
            // 
            // picTankBlank
            // 
            this.picTankBlank.Image = global::Tanks.Properties.Resources.Green_Tank;
            this.picTankBlank.Location = new System.Drawing.Point(815, 398);
            this.picTankBlank.Name = "picTankBlank";
            this.picTankBlank.Size = new System.Drawing.Size(75, 75);
            this.picTankBlank.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picTankBlank.TabIndex = 0;
            this.picTankBlank.TabStop = false;
            this.picTankBlank.Click += new System.EventHandler(this.picTankBlank_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SandyBrown;
            this.ClientSize = new System.Drawing.Size(902, 485);
            this.Controls.Add(this.barrier2);
            this.Controls.Add(this.barrier1);
            this.Controls.Add(this.picEnemyBlank);
            this.Controls.Add(this.lblMiddleU);
            this.Controls.Add(this.lblMiddleL);
            this.Controls.Add(this.lblMiddleR);
            this.Controls.Add(this.lblMiddleD);
            this.Controls.Add(this.lblBullet);
            this.Controls.Add(this.picTankYouU);
            this.Controls.Add(this.picTankYouD);
            this.Controls.Add(this.picTankYouR);
            this.Controls.Add(this.picTankYouL);
            this.Controls.Add(this.picTankBlank);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "`";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmMain_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmMain_KeyUp);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picEnemyBlank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTankYouU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTankYouD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTankYouR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTankYouL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTankBlank)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picTankBlank;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Timer timerL;
        private System.Windows.Forms.Timer timerR;
        private System.Windows.Forms.Timer timerU;
        private System.Windows.Forms.Timer timerD;
        private System.Windows.Forms.PictureBox picTankYouL;
        private System.Windows.Forms.PictureBox picTankYouR;
        private System.Windows.Forms.PictureBox picTankYouD;
        private System.Windows.Forms.PictureBox picTankYouU;
        private System.Windows.Forms.Label lblBullet;
        private System.Windows.Forms.Label lblMiddleD;
        private System.Windows.Forms.Label lblMiddleR;
        private System.Windows.Forms.Label lblMiddleL;
        private System.Windows.Forms.Timer bullettimer;
        private System.Windows.Forms.Label lblMiddleU;
        private System.Windows.Forms.PictureBox picEnemyBlank;
        private System.Windows.Forms.Label barrier1;
        private System.Windows.Forms.Label barrier2;
        private System.Windows.Forms.Timer EnemyTimer;
    }
}

