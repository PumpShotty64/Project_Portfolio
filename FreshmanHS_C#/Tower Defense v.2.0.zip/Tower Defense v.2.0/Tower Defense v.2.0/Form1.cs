﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tower_Defense_v._2._0
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //variable for key value
            int whichkey = e.KeyValue;

            if (whichkey == 38)
            {
                TimerMovementYou.Enabled = true;                
            }
            else if (whichkey == 40)
            {
                TimerMovementYouDown.Enabled = true;
            }
            if (whichkey == 32)
            {
                lblBullet.Left = lblMiddle.Left;
                lblBullet.Top = lblMiddle.Top;
                TimerBullet.Enabled = true;
                lblBullet.Visible = true;
                lblBullet.BringToFront();
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            //variable for key value
            int whichkey = e.KeyValue;

            if (whichkey == 38)
            {
                TimerMovementYou.Enabled = false;
            }
            else if (whichkey == 40)
            {
                TimerMovementYouDown.Enabled = false;
            }
        }

        private void TimerMovementYou_Tick(object sender, EventArgs e)
        {
            //moves defensive tank up
            if (picTankYou.Top >= lblBarrierTop.Bottom)
            {
                picTankYou.Top -= 1;
                lblMiddle.Top -= 1;
            }
        }

        private void TimerMovementYouDown_Tick(object sender, EventArgs e)
        {
            //moves defensive tank down
            if (picTankYou.Bottom <= lblBarrierBottom.Top)
            {
                picTankYou.Top += 1;
                lblMiddle.Top += 1;
            }
        }

        private void TimerBullet_Tick(object sender, EventArgs e)
        {

            //sets a hitbox for the bullet and tank
            Rectangle WallBox = new Rectangle(picWall.Left, picWall.Top, picWall.Width, picWall.Height);
            Rectangle BulletBox = new Rectangle(lblBullet.Left, lblBullet.Top, lblBullet.Width, lblBullet.Height);

            //moves the bullet at this speed
            lblBullet.Left -= 4;

            //recalls bullet if it hits wall
            if (BulletBox.IntersectsWith(WallBox))
            {
                lblBullet.Left = lblMiddle.Left;
                lblBullet.Top = lblMiddle.Top;
                lblBullet.Visible = false;
                TimerBullet.Enabled = false;
            }
            else if (lblBullet.Left <= -20)
            {
                lblBullet.Left = lblMiddle.Left;
                lblBullet.Top = lblMiddle.Top;
                lblBullet.Visible = false;
                TimerBullet.Enabled = false;
            }
        }

        private void picWall_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }
    }
}
