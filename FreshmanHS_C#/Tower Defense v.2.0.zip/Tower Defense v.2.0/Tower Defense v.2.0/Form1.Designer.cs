﻿namespace Tower_Defense_v._2._0
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblBarrierTop = new System.Windows.Forms.Label();
            this.lblBarrierBottom = new System.Windows.Forms.Label();
            this.grpTowerShop = new System.Windows.Forms.GroupBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.picCannonTower = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.TimerMovementYou = new System.Windows.Forms.Timer(this.components);
            this.TimerMovementYouDown = new System.Windows.Forms.Timer(this.components);
            this.lblBullet = new System.Windows.Forms.Label();
            this.TimerBullet = new System.Windows.Forms.Timer(this.components);
            this.lblMiddle = new System.Windows.Forms.Label();
            this.picEmptyTower7 = new System.Windows.Forms.PictureBox();
            this.picEmptyTower6 = new System.Windows.Forms.PictureBox();
            this.picEmptyTower4 = new System.Windows.Forms.PictureBox();
            this.picEmptyTower5 = new System.Windows.Forms.PictureBox();
            this.picEmptyTower3 = new System.Windows.Forms.PictureBox();
            this.picEmptyTower2 = new System.Windows.Forms.PictureBox();
            this.picEmptyTower1 = new System.Windows.Forms.PictureBox();
            this.picWall = new System.Windows.Forms.PictureBox();
            this.picTankYou = new System.Windows.Forms.PictureBox();
            this.picMapLevel1 = new System.Windows.Forms.PictureBox();
            this.grpTowerShop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCannonTower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWall)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTankYou)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMapLevel1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblBarrierTop
            // 
            this.lblBarrierTop.BackColor = System.Drawing.Color.Gray;
            this.lblBarrierTop.Location = new System.Drawing.Point(933, 103);
            this.lblBarrierTop.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBarrierTop.Name = "lblBarrierTop";
            this.lblBarrierTop.Size = new System.Drawing.Size(41, 12);
            this.lblBarrierTop.TabIndex = 1;
            this.lblBarrierTop.Visible = false;
            // 
            // lblBarrierBottom
            // 
            this.lblBarrierBottom.BackColor = System.Drawing.Color.Gray;
            this.lblBarrierBottom.Location = new System.Drawing.Point(933, 404);
            this.lblBarrierBottom.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBarrierBottom.Name = "lblBarrierBottom";
            this.lblBarrierBottom.Size = new System.Drawing.Size(41, 12);
            this.lblBarrierBottom.TabIndex = 2;
            this.lblBarrierBottom.Visible = false;
            // 
            // grpTowerShop
            // 
            this.grpTowerShop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.grpTowerShop.Controls.Add(this.pictureBox7);
            this.grpTowerShop.Controls.Add(this.pictureBox5);
            this.grpTowerShop.Controls.Add(this.pictureBox3);
            this.grpTowerShop.Controls.Add(this.picCannonTower);
            this.grpTowerShop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTowerShop.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.grpTowerShop.Location = new System.Drawing.Point(252, 449);
            this.grpTowerShop.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpTowerShop.Name = "grpTowerShop";
            this.grpTowerShop.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpTowerShop.Size = new System.Drawing.Size(932, 128);
            this.grpTowerShop.TabIndex = 3;
            this.grpTowerShop.TabStop = false;
            this.grpTowerShop.Text = "Tower Shop";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Tower_Defense_v._2._0.Properties.Resources.EmptyTower;
            this.pictureBox7.Location = new System.Drawing.Point(704, 21);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(108, 100);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 22;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Tower_Defense_v._2._0.Properties.Resources.Rocket_Tower_Stock;
            this.pictureBox5.Location = new System.Drawing.Point(472, 21);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(108, 100);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 20;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Tower_Defense_v._2._0.Properties.Resources.Laser_Tower_Stock;
            this.pictureBox3.Location = new System.Drawing.Point(240, 21);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(108, 100);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 18;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // picCannonTower
            // 
            this.picCannonTower.Image = global::Tower_Defense_v._2._0.Properties.Resources.Cannon_Tower_Stock;
            this.picCannonTower.Location = new System.Drawing.Point(8, 21);
            this.picCannonTower.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picCannonTower.Name = "picCannonTower";
            this.picCannonTower.Size = new System.Drawing.Size(108, 100);
            this.picCannonTower.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCannonTower.TabIndex = 16;
            this.picCannonTower.TabStop = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(-5, 449);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 128);
            this.label1.TabIndex = 4;
            // 
            // TimerMovementYou
            // 
            this.TimerMovementYou.Interval = 1;
            this.TimerMovementYou.Tick += new System.EventHandler(this.TimerMovementYou_Tick);
            // 
            // TimerMovementYouDown
            // 
            this.TimerMovementYouDown.Interval = 1;
            this.TimerMovementYouDown.Tick += new System.EventHandler(this.TimerMovementYouDown_Tick);
            // 
            // lblBullet
            // 
            this.lblBullet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblBullet.Location = new System.Drawing.Point(901, 257);
            this.lblBullet.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBullet.Name = "lblBullet";
            this.lblBullet.Size = new System.Drawing.Size(13, 6);
            this.lblBullet.TabIndex = 6;
            this.lblBullet.Visible = false;
            // 
            // TimerBullet
            // 
            this.TimerBullet.Interval = 10;
            this.TimerBullet.Tick += new System.EventHandler(this.TimerBullet_Tick);
            // 
            // lblMiddle
            // 
            this.lblMiddle.BackColor = System.Drawing.Color.White;
            this.lblMiddle.Location = new System.Drawing.Point(901, 257);
            this.lblMiddle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMiddle.Name = "lblMiddle";
            this.lblMiddle.Size = new System.Drawing.Size(13, 6);
            this.lblMiddle.TabIndex = 8;
            this.lblMiddle.Visible = false;
            // 
            // picEmptyTower7
            // 
            this.picEmptyTower7.Image = global::Tower_Defense_v._2._0.Properties.Resources.EmptyTower;
            this.picEmptyTower7.Location = new System.Drawing.Point(788, 316);
            this.picEmptyTower7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picEmptyTower7.Name = "picEmptyTower7";
            this.picEmptyTower7.Size = new System.Drawing.Size(36, 33);
            this.picEmptyTower7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEmptyTower7.TabIndex = 15;
            this.picEmptyTower7.TabStop = false;
            // 
            // picEmptyTower6
            // 
            this.picEmptyTower6.Image = global::Tower_Defense_v._2._0.Properties.Resources.EmptyTower;
            this.picEmptyTower6.Location = new System.Drawing.Point(656, 171);
            this.picEmptyTower6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picEmptyTower6.Name = "picEmptyTower6";
            this.picEmptyTower6.Size = new System.Drawing.Size(36, 33);
            this.picEmptyTower6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEmptyTower6.TabIndex = 14;
            this.picEmptyTower6.TabStop = false;
            // 
            // picEmptyTower4
            // 
            this.picEmptyTower4.Image = global::Tower_Defense_v._2._0.Properties.Resources.EmptyTower;
            this.picEmptyTower4.Location = new System.Drawing.Point(460, 197);
            this.picEmptyTower4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picEmptyTower4.Name = "picEmptyTower4";
            this.picEmptyTower4.Size = new System.Drawing.Size(36, 33);
            this.picEmptyTower4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEmptyTower4.TabIndex = 13;
            this.picEmptyTower4.TabStop = false;
            // 
            // picEmptyTower5
            // 
            this.picEmptyTower5.Image = global::Tower_Defense_v._2._0.Properties.Resources.EmptyTower;
            this.picEmptyTower5.Location = new System.Drawing.Point(460, 288);
            this.picEmptyTower5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picEmptyTower5.Name = "picEmptyTower5";
            this.picEmptyTower5.Size = new System.Drawing.Size(36, 33);
            this.picEmptyTower5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEmptyTower5.TabIndex = 12;
            this.picEmptyTower5.TabStop = false;
            // 
            // picEmptyTower3
            // 
            this.picEmptyTower3.Image = global::Tower_Defense_v._2._0.Properties.Resources.EmptyTower;
            this.picEmptyTower3.Location = new System.Drawing.Point(359, 314);
            this.picEmptyTower3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picEmptyTower3.Name = "picEmptyTower3";
            this.picEmptyTower3.Size = new System.Drawing.Size(36, 33);
            this.picEmptyTower3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEmptyTower3.TabIndex = 11;
            this.picEmptyTower3.TabStop = false;
            // 
            // picEmptyTower2
            // 
            this.picEmptyTower2.Image = global::Tower_Defense_v._2._0.Properties.Resources.EmptyTower;
            this.picEmptyTower2.Location = new System.Drawing.Point(359, 174);
            this.picEmptyTower2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picEmptyTower2.Name = "picEmptyTower2";
            this.picEmptyTower2.Size = new System.Drawing.Size(36, 33);
            this.picEmptyTower2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEmptyTower2.TabIndex = 10;
            this.picEmptyTower2.TabStop = false;
            // 
            // picEmptyTower1
            // 
            this.picEmptyTower1.Image = global::Tower_Defense_v._2._0.Properties.Resources.EmptyTower;
            this.picEmptyTower1.Location = new System.Drawing.Point(128, 244);
            this.picEmptyTower1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picEmptyTower1.Name = "picEmptyTower1";
            this.picEmptyTower1.Size = new System.Drawing.Size(36, 33);
            this.picEmptyTower1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEmptyTower1.TabIndex = 9;
            this.picEmptyTower1.TabStop = false;
            // 
            // picWall
            // 
            this.picWall.Image = global::Tower_Defense_v._2._0.Properties.Resources.Wall;
            this.picWall.Location = new System.Drawing.Point(464, 10);
            this.picWall.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picWall.Name = "picWall";
            this.picWall.Size = new System.Drawing.Size(49, 181);
            this.picWall.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picWall.TabIndex = 7;
            this.picWall.TabStop = false;
            this.picWall.Click += new System.EventHandler(this.picWall_Click);
            // 
            // picTankYou
            // 
            this.picTankYou.Image = global::Tower_Defense_v._2._0.Properties.Resources.Defensive_Tank;
            this.picTankYou.Location = new System.Drawing.Point(905, 230);
            this.picTankYou.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picTankYou.Name = "picTankYou";
            this.picTankYou.Size = new System.Drawing.Size(93, 59);
            this.picTankYou.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picTankYou.TabIndex = 5;
            this.picTankYou.TabStop = false;
            // 
            // picMapLevel1
            // 
            this.picMapLevel1.Image = global::Tower_Defense_v._2._0.Properties.Resources.TD_Map;
            this.picMapLevel1.Location = new System.Drawing.Point(-1, -1);
            this.picMapLevel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picMapLevel1.Name = "picMapLevel1";
            this.picMapLevel1.Size = new System.Drawing.Size(1185, 582);
            this.picMapLevel1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picMapLevel1.TabIndex = 0;
            this.picMapLevel1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 578);
            this.Controls.Add(this.picEmptyTower7);
            this.Controls.Add(this.picEmptyTower6);
            this.Controls.Add(this.picEmptyTower4);
            this.Controls.Add(this.picEmptyTower5);
            this.Controls.Add(this.picEmptyTower3);
            this.Controls.Add(this.picEmptyTower2);
            this.Controls.Add(this.picEmptyTower1);
            this.Controls.Add(this.lblMiddle);
            this.Controls.Add(this.picWall);
            this.Controls.Add(this.lblBullet);
            this.Controls.Add(this.picTankYou);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grpTowerShop);
            this.Controls.Add(this.lblBarrierBottom);
            this.Controls.Add(this.lblBarrierTop);
            this.Controls.Add(this.picMapLevel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Tower Defense v.2.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            this.grpTowerShop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCannonTower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyTower1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWall)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTankYou)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMapLevel1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picMapLevel1;
        private System.Windows.Forms.Label lblBarrierTop;
        private System.Windows.Forms.Label lblBarrierBottom;
        private System.Windows.Forms.GroupBox grpTowerShop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picTankYou;
        private System.Windows.Forms.Timer TimerMovementYou;
        private System.Windows.Forms.Timer TimerMovementYouDown;
        private System.Windows.Forms.Label lblBullet;
        private System.Windows.Forms.Timer TimerBullet;
        private System.Windows.Forms.PictureBox picWall;
        private System.Windows.Forms.Label lblMiddle;
        private System.Windows.Forms.PictureBox picEmptyTower1;
        private System.Windows.Forms.PictureBox picEmptyTower2;
        private System.Windows.Forms.PictureBox picEmptyTower3;
        private System.Windows.Forms.PictureBox picEmptyTower5;
        private System.Windows.Forms.PictureBox picEmptyTower4;
        private System.Windows.Forms.PictureBox picEmptyTower6;
        private System.Windows.Forms.PictureBox picEmptyTower7;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox picCannonTower;
    }
}

