﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player_Score : MonoBehaviour {

    private float timeLeft = 120;
    public static int score = 0;
    public int coins = 0;
    public GameObject timeLeftUI;
    public GameObject scoreUI;
    public GameObject coinUI;

	// Use this for initialization
	void Start () {
        //Data_Management.datamanagement.LoadData();
        //score = Data_Management.datamanagement.highScore;
    }
	
	// Update is called once per frame
	void Update () {
        timeLeft -= Time.deltaTime;
        timeLeftUI.gameObject.GetComponent<Text>().text = ("TIME\n" + (int)timeLeft);
        scoreUI.gameObject.GetComponent<Text>().text = ("MARIO\n" + score);
        coinUI.gameObject.GetComponent<Text>().text = ("X " + coins);
        if (timeLeft < 0.1f) {
            SceneManager.LoadScene("Level001");
        }
	}

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Coin") {
            score += 10;
            coins++;
            Destroy(collision.gameObject);
        }
    }

    void CountScore() {
        score = score + (int)(timeLeft * 10);
        //Data_Management.datamanagement.highScore = score;
        //Data_Management.datamanagement.SaveData();
    }
}
