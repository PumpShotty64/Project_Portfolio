﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goomba_Death : MonoBehaviour {

    private float deathTimer = 0;
    private int count = 0;
	
	// Update is called once per frame
	void Update () {
        if (gameObject.GetComponent<Rigidbody2D>().gravityScale == 0) {
            if (count == 0) {
                Player_Score.score += 100;
                count++;
            }
            kill();
        }
	}

    void kill() {
        deathTimer += Time.deltaTime;
        if (deathTimer >= 1f) {
            Destroy(gameObject);
        }
    }
}
