﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Player_Movement : MonoBehaviour {

    public int speed = 12;
    public int jumpPower = 900;
    public float maxJumpMultiplier = 7f;
    public float lowJumpMultiplier = 5f;
    private float moveX;
    public bool isGrounded;

    Rigidbody2D rb2D;

    private void Awake() {  //initializing
        rb2D = gameObject.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update () {
        PlayerMove();
        PlayerRaycast();
	}

    void PlayerMove() {

        //CONTROLS
        moveX = Input.GetAxis("Horizontal");  //returns value from -1 to 1
        //Player Direction
        if (moveX < 0.0f) {  //left
            GetComponent<SpriteRenderer>().flipX = true;
        }
        else if (moveX > 0.0f) {  //right
            GetComponent<SpriteRenderer>().flipX = false;
        }

        //JUMP
        if (Input.GetButtonDown("Jump") && isGrounded) {
            rb2D.AddForce(Vector2.up * jumpPower);
        }
        if (rb2D.velocity.y < 0) {  //faster fall
            rb2D.velocity += Vector2.up * Physics2D.gravity.y * (maxJumpMultiplier - 1) * Time.deltaTime;  //Time.deltaTime is how many seconds in a frame
        }
        else if (rb2D.velocity.y > 0 && !Input.GetButton("Jump")) {
            rb2D.velocity += Vector2.up * Physics2D.gravity.y * (lowJumpMultiplier - 1) * Time.deltaTime;  //Time.deltaTime is how many seconds in a frame
        }

        //MOVEMENT & PHYSICS
        rb2D.velocity = new Vector2(moveX * speed, gameObject.GetComponent<Rigidbody2D>().velocity.y);

        //ANIMATION
        if (moveX != 0) {
            GetComponent<Animator>().SetBool("isRunning", true);
        }
        else {
            GetComponent<Animator>().SetBool("isRunning", false);
        }
        if (isGrounded == false)
        {
            GetComponent<Animator>().SetBool("isJumping", true);
        }
        else if (isGrounded == true) {
            GetComponent<Animator>().SetBool("isJumping", false);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        isGrounded = true;
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        isGrounded = true;
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        isGrounded = false;
    }

    void PlayerRaycast()
    {
        //UPWARDS RAY
        RaycastHit2D rayUpR = Physics2D.Raycast(new Vector2(transform.position.x + 0.35f, transform.position.y), Vector2.up);
        RaycastHit2D rayUpL = Physics2D.Raycast(new Vector2(transform.position.x - 0.35f, transform.position.y), Vector2.up);

        if (rayUpR.collider != null && rayUpR.distance < 0.5f && rayUpR.collider.tag == "Breakable")
        {
            rb2D.velocity = new Vector2(0, 0);
            rayUpR.collider.gameObject.GetComponent<SpriteRenderer>().flipX = true;
        }
        else if (rayUpL.collider != null && rayUpL.distance < 0.5f && rayUpL.collider.tag == "Breakable")
        {
            rb2D.velocity = new Vector2(0, 0);
            rayUpL.collider.gameObject.GetComponent<SpriteRenderer>().flipX = true;
        }

        //DOWNWARDS RAY
        //MAKES TWO SO THAT WHEN MARIO IS ON THE EDGE, IT REGISTERS
        RaycastHit2D rayDownR = Physics2D.Raycast(new Vector2(transform.position.x + 0.35f, transform.position.y), Vector2.down);
        RaycastHit2D rayDownL = Physics2D.Raycast(new Vector2(transform.position.x - 0.35f, transform.position.y), Vector2.down);

        //RIGHT RAYCAST
        if (rayDownR.collider != null && rayDownR.distance < 0.5f && rayDownR.collider.tag == "Enemy")
        {
            rb2D.velocity = new Vector2(0, 0);
            rb2D.AddForce(Vector2.up * 1250);
            //KILLS GOOMBA
            rayDownR.collider.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0, 0);
            rayDownR.collider.gameObject.GetComponent<Rigidbody2D>().gravityScale = 0;
            rayDownR.collider.gameObject.GetComponent<BoxCollider2D>().enabled = false;
            rayDownR.collider.gameObject.GetComponent<Goomba_Movement>().enabled = false;
            rayDownR.collider.gameObject.GetComponent<Animator>().SetBool("isDead", true);
        }
        //LEFT RAYCAST
        else if (rayDownL.collider != null && rayDownL.distance < 0.5f && rayDownL.collider.tag == "Enemy")
        {
            rb2D.velocity = new Vector2(0, 0);
            rb2D.AddForce(Vector2.up * 1250);
            //KILLS GOOMBA
            rayDownL.collider.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0, 0);
            rayDownL.collider.gameObject.GetComponent<Rigidbody2D>().gravityScale = 0;
            rayDownL.collider.gameObject.GetComponent<BoxCollider2D>().enabled = false;
            rayDownL.collider.gameObject.GetComponent<Goomba_Movement>().enabled = false;
            rayDownL.collider.gameObject.GetComponent<Animator>().SetBool("isDead", true);
        }
        //USE RAYCAST TO DO JUMP BECAUSE ON COLLISION CAUSES THING TO WALLJUMP
    }
}
