﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goomba_Movement : MonoBehaviour {

    public int speed;
    public int xDirection;

    void Update()
    {
        gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(xDirection, 0) * speed;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag != "Floor" && collision.gameObject.tag != "Player") {
            xDirection *= -1;
        }
    }
}
