﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Break_Block : MonoBehaviour
{

    Tilemap map;
    GridLayout gridLayout;
    Vector3Int cellPosition;

    private void Start()
    {
        map = gameObject.GetComponent<Tilemap>();
        gridLayout = transform.parent.GetComponentInParent<GridLayout>();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            //converts world position to cell position --- returns int position
            cellPosition = gridLayout.WorldToCell(collision.gameObject.transform.position);
            map.SetTile(new Vector3Int(cellPosition.x, cellPosition.y + 1, 0), null);
        }
    }
}
