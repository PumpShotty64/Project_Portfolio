import java.applet.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;

public class Craps extends JApplet implements ActionListener{
	//declare our components or fields
	//a field is a global level variable
	JButton btnAdd = new JButton("Roll");
	JTextArea txaDiceRoll = new JTextArea(10, 20);
	JPanel pnlMain = new JPanel();
	JPanel pnlInput = new JPanel();
	JPanel pnlOutput = new JPanel();
	
	//create the init method
	//init is first program to run
	public void init() {
		//place components on the applet panel
		DesignInputPanel();
		DesignOutputPanel();
		pnlMain.add(pnlInput);
		pnlMain.add(btnAdd);
		pnlMain.add(pnlOutput);
		resize(400 , 300);
		//******set the content to the panel
		//or it won't show up
		setContentPane(pnlMain);
		btnAdd.addActionListener(this);		
	}
	//when you push the button it comes this method
	public void actionPerformed(ActionEvent event) {
		//step 1 declare variables
		int roll1,
			roll2,
			rollSum1,
			rollSum2,
			rollTracker;
		
		String GameText;
		
		//step 3 calculate
		//we are going to connect the classes
		CrapsCalculations TheRandomRollClass = new CrapsCalculations();
		roll1 = TheRandomRollClass.getRoll1();
		roll2 = TheRandomRollClass.getRoll2();
		rollSum1 = TheRandomRollClass.getPlayerRollSum();
		rollSum2 = TheRandomRollClass.getRandomRollSum();
		rollTracker = TheRandomRollClass.getRollTracker();
		GameText = TheRandomRollClass.getString();
		
		
		
		txaDiceRoll.setText("");
		
		//step 4 output
//		Random_Dice_Format roundNumbers = new Random_Dice_Format();
		
		
		txaDiceRoll.append(	"Dice: " + "\t" + roll1 + "\t" + roll2 + "\n" + 
							"Total: " + "\t" + "\t" + rollSum2 + "\n" +
							"Your Point: " + "\t" + "\t" + rollSum1 + "\n" + "\n" +
							"Rolls this round: " + "\t" + rollTracker + "\n" + "\n" +
							GameText + "\n" +
							"-----------------------------------------------------" + "\n");
		}
	
	public void DesignInputPanel(){
		pnlInput.setLayout(new GridLayout(0, 2));
	}
	
	public void DesignOutputPanel(){
		pnlOutput.setLayout(new GridLayout(0, 1));
		pnlOutput.add(txaDiceRoll);
	}
}
