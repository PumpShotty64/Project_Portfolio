public class CrapsCalculations {
	private int randomRoll1, 
				randomRoll2,
				howMany;
	
	private static int 	rollTracker,
						randomRollSum,
						playerRollSum,
						GameStatus;
	
	String GameText = "";
	
	CrapsCalculations(){
		CalculateRoll();
	}
	
	private void CalculateRoll() {
		//dice roll
		randomRoll1 = (int)(Math.random() * 6 + 1);
		randomRoll2 = (int)(Math.random() * 6 + 1);
		rollTracker++;
		randomRollSum = randomRoll1 + randomRoll2;
		
		//first roll win lose conditions
		if(rollTracker == 1) {
			playerRollSum = randomRoll1 + randomRoll2;
			GameStatus = 1;
		}
		
		else if(rollTracker == 1 && randomRollSum == 2 || randomRollSum == 3 || randomRollSum == 12) {
			GameText = "You Lose";
			GameStatus = 0;
			rollTracker = 0;
		}
		
		else if(rollTracker == 1 && randomRollSum == 7 || randomRollSum == 11) {
			GameText = "You Win";
			GameStatus = 0;
			rollTracker = 0;
		}
		
		//after first roll win conditions
		else if (rollTracker > 1) {
			if(randomRollSum == 7) {
				GameStatus = 3;
			}
			else if(randomRollSum == playerRollSum) {
				GameStatus = 2;
			}
		}
		
		
		//Win Lose Continue text
		if(GameStatus == 1) {
			GameText = "Continue";
		}
		else if(GameStatus == 2) {
			GameText = "You Win";
			GameStatus = 0;
			rollTracker = 0;
		}
		else if(GameStatus == 3) {
			GameText = "You Lose";
			GameStatus = 0;
			rollTracker = 0;
		}
	}
	
	public int getRoll1() {
		return randomRoll1;
	}
	
	public int getRoll2() {
		return randomRoll2;
	}
	
	public int getRandomRollSum() {
		return randomRollSum;
	}
	
	public int getPlayerRollSum() {
		return playerRollSum;
	}
	
	public int getRollTracker() {
		return rollTracker;
	}
	
	public String getString() {
		return GameText;
	}
}
