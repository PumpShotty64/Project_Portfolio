import java.applet.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.Console;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;

public class Knight_Tour extends JApplet implements ActionListener{
	//declare our components or fields
	//a field is a global level variable
	JTextField txtRows = new JTextField(4);
	JTextField txtCols = new JTextField(4);
	JButton btnSet = new JButton("Set Position");
	JButton btnRun = new JButton("Run");
	JButton btnReset = new JButton("Reset");
	JTextArea txaOutput = new JTextArea(9, 11);
	JPanel pnlMain = new JPanel();
	JPanel pnlInput = new JPanel();
	JPanel pnlOutput = new JPanel();
	
	int[][] boardArray = new int[8][8];
	int theKnight = 1;
	int rowTracker;
	int posX;
	int posY;
	int randomMove;
	int initialX;
	int initialY;
	int temp;
	int max = 0;
	boolean condition = false;
	
	
	public void init() {
		//place components on the applet panel
		DesignInputPanel();
		DesignOutputPanel();
		pnlMain.add(pnlInput);
		pnlMain.add(btnSet);
		pnlMain.add(btnRun);
		pnlMain.add(btnReset);
		pnlMain.add(pnlOutput);
		resize(800 , 400);
		//******set the content to the panel
		//or it won't show up
		setContentPane(pnlMain);
		
		txtRows.requestFocus();
		btnReset.addActionListener(this);
		btnSet.addActionListener(this);
		btnRun.setEnabled(false);
		
		for(int i = 0; i < 8; i++) {
			for(int j = 0; j < 8; j++) {
				boardArray[i][j] = 0;
				txaOutput.append(boardArray[i][j] + "  ");
			}
			txaOutput.append("\n");
		}	
	}
	//when you push the button it comes this method
	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == btnSet) {
			posY = Integer.parseInt(txtRows.getText()) - 1;
			posX = Integer.parseInt(txtCols.getText()) - 1;
			initialX = posX;
			initialY = posY;
			if(posX > 7 || posY > 7) {
				showStatus("Please input numbers from 1 to 8.");
				txtRows.setText("");
				txtCols.setText("");
			}
			if(posX < 8 && posY < 8) {
				txaOutput.setText("");
				System.out.println("Position: " + posX + ", " + posY);
				boardArray[posY][posX] = theKnight;
				for(int i = 0; i < 8; i++) {
					for(int j = 0; j < 8; j++) {
						txaOutput.append(boardArray[i][j] + "    ");
					}
					txaOutput.append("\n");
				}
				btnRun.setEnabled(true);
				btnRun.addActionListener(this);
				btnSet.setEnabled(false);
				txtRows.setEnabled(false);
				txtCols.setEnabled(false);
			}
		}
		
		if(event.getSource() == btnRun) {
			while(theKnight < 64) { //auto runs the program. Runs each turn
				int infinity = 1;
				txaOutput.setText("");
				
				
				
				
				for(int i = 0; i < infinity; i++) {
					randomMove = (int) (Math.random() * 8 + 1);
					if(randomMove == 1) {
						if(posX > 0 && posY > 1 && boardArray[posY - 2][posX - 1] == 0) {
							posX -= 1;
							posY -= 2;
							theKnight++;
							break;
						}
					}
					else if(randomMove == 2) {
						if(posX > 1 && posY > 0 && boardArray[posY - 1][posX - 2] == 0) {
							posX -= 2;
							posY -= 1;
							theKnight++;
							break;
						}
					}
					else if(randomMove == 3) {
						if(posX > 0 && posY < 6 && boardArray[posY + 2][posX - 1] == 0) {
							posX -= 1;
							posY += 2;
							theKnight++;
							break;
						}
					}
					else if(randomMove == 4) {
						if(posX > 1 && posY < 7 && boardArray[posY + 1][posX - 2] == 0) {
							posX -= 2;
							posY += 1;
							theKnight++;
							break;
						}
					}
					else if(randomMove == 5) {
						if(posX < 7 && posY > 1 && boardArray[posY - 2][posX + 1] == 0) {
							posX += 1;
							posY -= 2;
							theKnight++;
							break;
						}
					}
					else if(randomMove == 6) {
						if(posX < 6 && posY > 0 && boardArray[posY - 1][posX + 2] == 0) {
							posX += 2;
							posY -= 1;
							theKnight++;
							break;
						}
					}
					else if(randomMove == 7) {
						if(posX < 6 && posY < 7 && boardArray[posY + 1][posX + 2] == 0) {
							posX += 2;
							posY += 1;
							theKnight++;
							break;
						}
					}
					else if(randomMove == 8) {
						if(posX < 7 && posY < 6 && boardArray[posY + 2][posX + 1] == 0) {	
							posX += 1;
							posY += 2;
							theKnight++;
							break;
						}
					}
					
					
					
					if(infinity > 1000) { //if none of the conditions above works, then:
						temp++;
						showStatus("You can no longer move. Please reset board.");
						if(theKnight < 64) { //if condition is false, stops resetting the board
							for(int k = 0; k < 8; k++) {
								for(int l = 0; l < 8; l++) {
									boardArray[k][l] = 0;
									txaOutput.append(boardArray[k][l] + "    ");
								}
							}
							System.out.println("Resets: " + temp);
							theKnight = 1;
							posX = initialX;
							posY = initialY;
							break;
						}
						condition = true; //do something with this
						break; //breaks out of the for loop
					}
					infinity++;
				} //end of for loop
				if(theKnight > max) {
					max = theKnight;
					System.out.println("CURRENT MAX: " + max);
				}
				boardArray[posY][posX] = theKnight;
//				if(condition = true) {
//					break;
//				}
			}	//end of while loop
			
			//displayed the board
			for(int i = 0; i < 8; i++) {
				for(int j = 0; j < 8; j++) {
					if(boardArray[i][j] < 10) {
						txaOutput.append(boardArray[i][j] + "    ");
					}
					else if(boardArray[i][j] >= 10) {
						txaOutput.append(boardArray[i][j] + "  ");
					}
				}
				txaOutput.append("\n");
			}
		}
		if(event.getSource() == btnReset) {
			txaOutput.setText("");
			btnRun.setEnabled(false);
			btnSet.setEnabled(true);
			txtRows.setEnabled(true);
			txtCols.setEnabled(true);
			txtRows.requestFocus();
			txtRows.setText("");
			txtCols.setText("");
			theKnight = 1;
			for(int i = 0; i < 8; i++) {
				for(int j = 0; j < 8; j++) {
					boardArray[i][j] = 0;
					txaOutput.append(boardArray[i][j] + "  ");
				}
				txaOutput.append("\n");
			}
		}
	}
	
	public void DesignInputPanel(){
		pnlInput.setLayout(new GridLayout(0, 2));
		pnlInput.add(new JLabel("Rows: "));
		pnlInput.add(txtRows);
		pnlInput.add(new JLabel("Columns: "));
		pnlInput.add(txtCols);
	}
	
	public void DesignOutputPanel(){
		pnlOutput.setLayout(new GridLayout(0, 1));
		pnlOutput.add(txaOutput);
	}
}

