
import java.applet.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.Console;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;

public class Binary_Search extends JApplet implements ActionListener{
	//declare our components or fields
	//a field is a global level variable
	JButton btnGenerate = new JButton("Generate");
	JButton btnSearch = new JButton("Search");
	JTextArea txaOutput = new JTextArea(9, 11);
	JPanel pnlMain = new JPanel();
	JPanel pnlInput = new JPanel();
	JPanel pnlOutput = new JPanel();
	
	boolean onOff = false;
	int thisNumber = -10;
	int randomNumbers;
	int[] binaryArray = new int[5000];
	int[] sortedArray;
	
	public void init() {
		//place components on the applet panel
		DesignInputPanel();
		DesignOutputPanel();
		pnlMain.add(pnlInput);
		pnlMain.add(btnGenerate);
		pnlMain.add(btnSearch);
		pnlMain.add(pnlOutput);
		resize(800 , 400);
		//******set the content to the panel
		//or it won't show up
		setContentPane(pnlMain);
		
		btnGenerate.addActionListener(this);
		btnSearch.addActionListener(this);
		btnGenerate.setEnabled(!onOff);
		btnSearch.setEnabled(onOff);
	}
	//when you push the button it comes this method
	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == btnGenerate) {
			onOff = true;	
			for(int n = 0; n < binaryArray.length; n++) {
				randomNumbers = (int) (Math.random() * 5000 + 1);
				binaryArray[n] = randomNumbers;
				System.out.println(binaryArray[n] + " : " + (n + 1));
			}
			
			int temp;
			sortedArray = new int[binaryArray.length];
			for(int i = 0; i < binaryArray.length - 1; i++) {
				for(int k = 0; k < binaryArray.length - 1; k++) {
					if(binaryArray[k] > binaryArray[k + 1]) {
						temp = binaryArray[k];
						binaryArray[k] = binaryArray[k + 1];
						binaryArray[k + 1] = temp;
						sortedArray = binaryArray;
					}
				}
			}
			for(int l = 0; l < sortedArray.length; l++) {
				System.out.println(sortedArray[l] + " : " + (l + 1));
			}
		}
		else if(event.getSource() == btnSearch) {
			String binaryString = "";
			String sequentialString = "";
			int binaryAverage;
			int sequentialAverage;
			Binary_Calculations TheBinarySearch = new Binary_Calculations(sortedArray);
			binaryAverage = TheBinarySearch.getAverageTimes();
			sequentialAverage = TheBinarySearch.getAverageTimes2();
			binaryString = "Binary Search Average Runs: " + binaryAverage;
			sequentialString = "Sequential Search Average Runs: " + sequentialAverage;
			txaOutput.append(sequentialString + "\n" + binaryString + "\n");
		}
		
		
		btnGenerate.setEnabled(!onOff);
		btnSearch.setEnabled(onOff);
	}
	
	public void DesignInputPanel(){
		pnlInput.setLayout(new GridLayout(0, 2));
		pnlInput.add(new JLabel("Find Number: "));
	}
	
	public void DesignOutputPanel(){
		pnlOutput.setLayout(new GridLayout(0, 1));
		pnlOutput.add(txaOutput);
	}
}

