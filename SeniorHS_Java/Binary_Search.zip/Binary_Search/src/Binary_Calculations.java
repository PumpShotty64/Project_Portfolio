public class Binary_Calculations {
	
	private int[] sortedArray;
	
	private int	lowerLimit = 0,
				upperLimit = 4999;
	
	private int theNumber;
	
	private int binaryRunTimes = 0;
	private int sequentialRunTimes = 0;
	
	private int averageTimes = 0;
	private int averageTimes2 = 0;
	private int totalTimes = 0;
	private int totalTimes2 = 0;
	
	private boolean onOff = false;
	
	//test variables
	private int loopTimes = 0;
	private int noNumber;
	private int yesNumber;
	
	Binary_Calculations(int[] theArray){
		sortedArray = theArray;
		BinarySearch();
	}
	
	private void BinarySearch() {
		
		for(int i = 0; i < 5000; i++) {
			//resets variables
			onOff = false;
			lowerLimit = 0;
			upperLimit = 5000;
			binaryRunTimes = 0;
			sequentialRunTimes = 0;
			theNumber = (int) (Math.random() * 5000 + 1);
			loopTimes ++;
			
			
			//Sequential Search
			for(int j = 0; j < 5000; j++) {
				sequentialRunTimes++;
				if(theNumber == sortedArray[j]) {
					System.out.println(theNumber + " : " + j);
					break;
				}
			}
			
			//testing purposes
//			if(sequentialRunTimes >= 5000) {
//				sequentialRunTimes = 2500;
//			}

			//binary search
			while(onOff == false) {
				int middle = (lowerLimit + upperLimit)/2;
				binaryRunTimes ++;
				System.out.println("------------------");
				System.out.println("(" + lowerLimit + ", " + upperLimit + ")");
				System.out.println("Middle Number: " + middle);
				if(binaryRunTimes > 15) {
					System.out.println("Number Not Found");
					noNumber++;
					onOff = true;
				}	
				else if(theNumber > sortedArray[middle]) {
					lowerLimit = middle + 1;
				}
				else if(theNumber < sortedArray[middle]) {
					upperLimit = middle - 1;
				}
				else if(theNumber == sortedArray[middle]) {
					System.out.println("Number Found: " + theNumber);
					System.out.println("Times Run: " + binaryRunTimes);
					System.out.println("Lower Bound: " + lowerLimit);
					System.out.println("Middle Number: " + middle);
					System.out.println("Upper Bound: " + upperLimit);
					yesNumber++;
					onOff = true;
				}		
			} //end of while loops
			
			totalTimes += binaryRunTimes;
			totalTimes2 += sequentialRunTimes;
			averageTimes = totalTimes/5000;
			averageTimes2 = totalTimes2/5000;
		}// end of for loop
			
		System.out.println("Total Sequential Run Times: " + totalTimes2);
		System.out.println("Sequential Average Runs: " + averageTimes2);
		System.out.println("Total Binary Run Times: " + totalTimes);
		System.out.println("Total loopTimes: " + loopTimes);
		System.out.println("Yes Number: " + yesNumber);
		System.out.println("No Number: " + noNumber);
		System.out.println("Binary Average Runs: " + averageTimes);
	}
	public int getAverageTimes() {
		return averageTimes;
	}
	public int getAverageTimes2() {
		return averageTimes2;
	}
}
