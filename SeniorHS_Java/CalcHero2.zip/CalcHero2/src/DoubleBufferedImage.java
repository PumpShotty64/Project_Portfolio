import java.applet.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.awt.image.BufferStrategy;
import java.util.EventObject;
import java.awt.event.ActionEvent;
import java.awt.event.*;
import java.util.Arrays;
import java.awt.Color;
import java.awt.Graphics;


public class DoubleBufferedImage extends JApplet implements ActionListener{
	
	//Layout
	JButton btnA = new JButton("A");
	JButton btnB = new JButton("B");
	JButton btnC = new JButton("C");
	JButton btnD = new JButton("D");
	JButton btnE = new JButton("E");
	JPanel pnlAnswers = new JPanel();
	
	
	final Object[] BUTTONS = {
		btnA, btnB, btnC, btnD, btnE	
	};
	int bIndex = 0;
	
	
	//characters
	Image 	playerImage,
			boss1Image,
			backgroundImage,
			arrowImage,
			bowImage;
	
	//position of characters
	int playerPositionX = 150,
		playerPositionY = 320;
	
	int bossX = 600,
		bossY = 227;
	
	int arrowX = 180,
		arrowY = 350;
	int arrowFrame = 0;
	int randomArrow = 0;
	
	//HP SYSTEM
	int healthW = 200;
	int damage = 50;
	
	int pHealth = 150;
	int pDamage = 15;
	
	
	//Tracks timer
	int ticks = 21;
	
	//tracker
	int bgTrack = 2;
	int endTrack = 0;
	int healthTrack = 0;
	int transTrack = 0;
	int totalQuestions = 0;
	
	//times
	Timer aniTimer = new Timer(5, this);
	
	//layout
	int rows = 8;
	int cols = 3;
	
	final String[] QUESTION_FILES = {
			"Q01A.png", "Q02E.png", "Q03A.png", "Q04B.png", "Q05C.png", "Q06A.png", "Q07B.png",
			"Q08A.png", "Q09A.png", "Q10D.png", "Q11C.png", "Q12B.png", "Q13D.png", "Q14B.png",
			"Q15C.png", "Q16D.png", "Q17A.png", "Q18B.png", "Q19C.png", "Q20D.png", "Q21A.png",
			"Q22B.png", "Q23C.png", "Q24D.png", "Q25A.png", "Q26B.png", "Q27C.png", "Q28D.png",
			"Q29A.png", "Q30B.png", "Q31C.png", "Q32D.png", "Q33A.png", "Q34B.png", "Q35C.png",
			"Q36D.png", "Q37A.png", "Q38B.png", "Q39C.png", "Q40D.png", "Q41A.png", "Q42B.png",
			"Q43C.png", "Q44D.png", "Q45A.png", "Q46B.png", "Q47C.png", "Q48D.png", "Q49A.png",
			"Q50B.png", "Q51C.png", "Q52D.png", "Q53A.png", "Q54B.png", "Q55C.png", "Q56D.png",
			"Q57D.png", "Q58B.png", "Q59C.png", "Q60D.png", "Q61A.png", "Q62B.png"
		};
	
	final String[] ANSWERS = {
			"A", "E", "A", "B", "C", "A", "B",
			"A", "A", "D", "C", "B", "D", "B",
			"C", "D", "A", "B", "C", "D", "A",
			"B", "C", "D", "A", "B", "C", "D",
			"A", "B", "C", "D", "A", "B", "C",
			"D", "A", "B", "C", "D", "A", "B",
			"C", "D", "A", "B", "C", "D", "A",
			"B", "C", "D", "A", "B", "C", "D",
			"A", "B", "C", "D", "A", "B"
		};
	
	final String[] BG_FILES = {
			"", "forestbackground.png", "skyBG.gif", "IceBackground (1).png"
		};
	
	final String[] BOSS_FILES = {
			"bloopman.gif", "Mr_RedSlime.gif", "penguinBabe.gif",
			"kingPenguin.gif", "babydeer.gif", "buffBoss.gif", "", ""
		};
	
	final String[] BOWARROW_FILES = {
			"pixelhunter1.gif", "pausehunter.gif", ""
		};
	
	final String[] ARROW_FILES = {
			"", "IcePixel.gif", "SImpleArrowfirearrow.gif", "poison arroiw.gif"
		};
	
	final String[] END_FILES = {
			"", "gameover.png", "YouWin.png"
		};
	
	Image[] questionArray = new Image[QUESTION_FILES.length];
	Image[] bgArray = new Image[BG_FILES.length];
	Image[] bossArray = new Image[BOSS_FILES.length];
	Image[] playerArray = new Image[BOWARROW_FILES.length];
	Image[] arrowArray = new Image[ARROW_FILES.length];
	Image[] endArray = new Image[END_FILES.length];
	
	//random numbers
	int randomNum;
	int randomBoss = 0;
	
	//animation track
	int playerAni = 0;
	int transQueue = 0;
	
	//User Answer
	String userAnswer = "";
	
	
	//Initializes Code
	public void init() {
		randomNum  = (int)(Math.random() * QUESTION_FILES.length);  //output numbers 0 - 41
		
		
		//ANIMATION STUFF
		for (int i = 0; i < questionArray.length; i++) {
			questionArray[i] = getImage(getDocumentBase(), QUESTION_FILES[i]);
		}
		for(int l = 0; l < bgArray.length; l++) {
			bgArray[l] = getImage(getDocumentBase(), BG_FILES[l]);
		}
		for(int j = 0; j < bossArray.length; j++) {
			bossArray[j] = getImage(getDocumentBase(), BOSS_FILES[j]);
		}
		for(int k = 0; k < playerArray.length; k++) {
			playerArray[k] = getImage(getDocumentBase(), BOWARROW_FILES[k]);
		}
		for(int l = 0; l < arrowArray.length; l++) {
			arrowArray[l] = getImage(getDocumentBase(), ARROW_FILES[l]);
		}
		for(int l = 0; l < endArray.length; l++) {
			endArray[l] = getImage(getDocumentBase(), END_FILES[l]);
		}
		
		//ANIMATION STUFF
//		for (int i = 0; i < questionArray.length; i++) {
//			try {
//				questionArray[i] = ImageIO.read(new File(QUESTION_FILES[i]));
//	        } catch (IOException ex) { } 
//		}
//		for(int l = 0; l < bgArray.length; l++) {
//			try {
//				bgArray[l] = ImageIO.read(new File(BG_FILES[l]));
//	        } catch (IOException ex) { } 
//		}
//		for(int j = 0; j < bossArray.length; j++) {
//			try {
//				bossArray[j] = ImageIO.read(new File(BOSS_FILES[j]));
//	        } catch (IOException ex) { } 
//		}
//		for(int k = 0; k < playerArray.length; k++) {
//			try {
//				playerArray[k] = ImageIO.read(new File(BOWARROW_FILES[k]));
//	        } catch (IOException ex) { } 
//		}
//		for(int l = 0; l < arrowArray.length; l++) {
//			try {
//				arrowArray[l] = ImageIO.read(new File(ARROW_FILES[l]));
//	        } catch (IOException ex) { } 
//		}
//		for(int l = 0; l < endArray.length; l++) {
//			try {
//				endArray[l] = ImageIO.read(new File(END_FILES[l]));
//	        } catch (IOException ex) { } 
//		}
//		for(int l = 0; l < transArray.length; l++) {
//			try {
//				transArray[l] = ImageIO.read(new File(TRANS_FILES[l]));
//	        } catch (IOException ex) { } 
//		}
		
		
		resize(1500, 675);		
		
//		BufferStrat SpriteClass = new BufferStrat(questionArray, bgArray, bossArray, playerArray, arrowArray, endArray, arrowX, arrowY);
		
		//GRID LAYOUT
		pnlAnswers.setLayout(new GridLayout(rows, cols));
		for(int j = 0; j < rows; j++) {
			for(int k = 0; k < cols; k++) {
				if(k < 2) {
					pnlAnswers.add(new JLabel(""));
				}
				else if(k == 2) {
					if(j >= 3) {
						pnlAnswers.add((Component) BUTTONS[bIndex]);
						bIndex++;
					}
					else {
						pnlAnswers.add(new JLabel(""));	
					}
				}
			}
		}
		setContentPane(pnlAnswers);
		
		
		btnA.addActionListener(this);
		btnB.addActionListener(this);
		btnC.addActionListener(this);
		btnD.addActionListener(this);
		btnE.addActionListener(this);
		
		System.out.println(randomNum);
	}
	
	
	public void actionPerformed(ActionEvent e) {
		Object objSource = e.getSource();
		
		if(objSource == btnA) {
			userAnswer = "A";
		}
		else if(objSource == btnB) {
			userAnswer = "B";
		}
		else if(objSource == btnC) {
			userAnswer = "C";
		}
		else if(objSource == btnD) {
			userAnswer = "D";
		}
		else if(objSource == btnE) {
			userAnswer = "E";
		}
		
		//IF ANSWER IS RIGHT
		if(userAnswer.compareTo(ANSWERS[randomNum]) == 0) {
			randomNum  = (int)(Math.random() * QUESTION_FILES.length);
			playerAni = 1;
			arrowFrame = 1;
			totalQuestions++;
			showStatus("Correct Answer");
			System.out.println("Question: " + (randomNum + 1));
			System.out.println("Answer: " + ANSWERS[randomNum]);
			System.out.println("Total Questions: " + totalQuestions);
			ticks = 0;
		}
		//if ANWER IS WRONG
		else {
			pHealth -= pDamage;
			showStatus("Incorrect Answer");
		}
		
		DoubleBufferedImage frame = new DoubleBufferedImage();
        frame.setVisible(true);
	}
	
//	public void updating() {
//		BufferStrategy bs = null;
//		
//		if(bs == null) {
//			createBufferStrategy(3);
//		}
//		
//		Graphics g = bs.getDrawGraphics();
//	    render(g);
//	    g.dispose();
//	    bs.show();
//	}
//	
//	public void render(Graphics g) {
//		g.drawImage(bgArray[bgTrack], 0, 0, 1000, 675, this);
//		g.drawImage(endArray[endTrack], 220, 250, 500, 200, this);
//		g.drawImage(playerArray[playerAni], playerPositionX, playerPositionY, 125, 200, this);
//		g.drawImage(bossArray[randomBoss], bossX, bossY, 300, 300, this);
//		g.drawImage(arrowArray[randomArrow], arrowX, arrowY, 150, 75, this);	
//	}
	
	public void paint(Graphics gr) {
		
		//background color
		getContentPane().setBackground(Color.black);
//		
		gr.setColor(getBackground());
//		super.paint(gr);
		
		Graphics2D g2D = (Graphics2D) gr;
		
		//draw player
		gr.drawImage(bgArray[bgTrack], 0, 0, 1000, 675, this);
		gr.drawImage(endArray[endTrack], 220, 250, 500, 200, this);
		gr.drawImage(playerArray[playerAni], playerPositionX, playerPositionY, 125, 200, this);
		gr.drawImage(bossArray[randomBoss], bossX, bossY, 300, 300, this);
		gr.drawImage(arrowArray[randomArrow], arrowX, arrowY, 150, 75, this);	
		
		//Health
		if(healthTrack == 0) {
			g2D.setStroke(new BasicStroke(5));
			g2D.setColor(Color.orange);
			gr.drawRect(635, 160, 205, 25);
			g2D.setColor(Color.red);
			gr.fillRect(638, 163, healthW, 20);
			g2D.setColor(Color.yellow);
			gr.drawRect(125, 270, 155, 25);
			g2D.setColor(Color.green);
			gr.fillRect(128, 273, pHealth, 20);	
		}

		//Questions
		gr.drawImage(questionArray[randomNum], 1000, 0, 500, 250, this);
		

		
		ticks++;
//		System.out.println(ticks);
		
		//BOW AND ARROW ANIMATION
		if(ticks >= 32) {
			playerAni = 0;
		}
		if(arrowFrame == 1) {
			if(ticks >= 25 && ticks < 52) {
				if(ticks == 25) {
					randomArrow = (int)(Math.random() * 3) + 1;
				}
				arrowX += 15;	
			}
			else if(ticks == 52) {
				randomArrow = 0;
				arrowX = 180;
				healthW -= damage;
				if(healthW <= 0) {
					randomBoss++;
					damage -= 7;
					if(randomBoss == 2) {
						bgTrack = 3;
					}
					else if(randomBoss == 4) {
						bgTrack = 1;
					}
					healthW = 200;
				}
			}
		}
		
		//LOSE WIN
		if(pHealth <= 0) {
			bgTrack = 0;
			playerAni = 2;
			randomBoss = 6;
			healthTrack = 1;
			endTrack = 1;
		}
		if(randomBoss == 6 && pHealth > 0) {
			bgTrack = 0;
			playerAni = 2;
			randomBoss = 6;
			healthTrack = 1;
			endTrack = 2;
		}
		
	}
	public void update(Graphics gr)
	{
		//call this the paint method
		paint(gr);	
	}
//	
	public static void main(String[] argv) {
	    JFrame frame = new JFrame();
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    DoubleBufferedImage a = new DoubleBufferedImage();

	    frame.getContentPane().add(a);
	    frame.setSize(300, 300);
	    a.init();
	    a.start();
	    frame.setVisible(true);

	}
	
	
	
}
