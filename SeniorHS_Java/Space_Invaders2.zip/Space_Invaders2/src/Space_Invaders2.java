
import java.applet.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.EventObject;
import java.awt.event.ActionEvent;
import java.awt.event.*;
import java.util.Arrays;


//USE ONE TIMER ONLY
public class Space_Invaders2 extends JApplet implements KeyListener, ActionListener
{
  //Declare components and variables

	JPanel mainPanel = new JPanel();
	Image 	playerImage,
			invaderImage;
	
	//Player Movement
	int xPositionInteger = 600;
	int yPositionInteger = 375;
	int xSpeed = 4;
	int ySpeed = 4;
	int directionTracker = 0;
	boolean rightOn = false;
	boolean leftOn = false;
	boolean upOn = false;
	boolean downOn = false;
	Timer myTimer = new Timer(10, this);
	
	//invader movement
	int invadeX = 0;
	int invadeY = 10;
	int invaderX1 = invadeX;
	boolean invaderMove = false;
	int health1 = 3;
	int randomizeX;
	int randomizeY;
	int randomizeZ;
	
	//Invaders
	DefineInvader Invaders[] = new DefineInvader[3];
	int Health[] = new int[3];
	int velX[] = new int[3];
	int velY[] = new int[3];
	
	//bullet stuff
	boolean paintBullet = false;
	boolean bulletMove = false;
	int bulletX;
	int bulletY;
	int bulletSpeed = 5;
	
	int counterTimer = 0;
	
	
	public void init()
	{
	  	playerImage = getImage(getDocumentBase(), "Battle Cruiser.png");
	  	invaderImage = getImage(getDocumentBase(), "Leviathan.png");
	  	
	  	for(int i = 0; i < 3; i++) {
	  		Invaders[i] = new DefineInvader();
	  		Health[i] = 3;
	  	}
	  	for(int j = 0; j < 3; j++) {
	  		int xpos = 0, ypos = 0, randomY, randomX, randomOne;
	  		randomOne = (int) (Math.random() * 2);
	  		if(randomOne == 0) {
	  			randomX = (int) (Math.random() * 2);
		  		if(randomX == 0) {
		  			ypos = (int) (Math.random() * 800);
		  			xpos = -100;	
		  		}
		  		else if(randomX == 1) {
		  			ypos = (int) (Math.random() * 800);
		  			xpos = 1350;
		  		}
	  		}
	  		else if(randomOne == 1) {
	  			randomY = (int) (Math.random() * 2);
		  		if(randomY == 0) {
		  			ypos = -100;
		  			xpos = (int) (Math.random() * 1150);
		  		}
		  		else if(randomY == 1) {
		  			ypos = 900;
		  			xpos = (int) (Math.random() * 1150);
		  		}		
			}
	  		Invaders[j].setInvader(xpos, ypos);
	  	}
	  	
	  	
		addKeyListener(this);
		setFocusable(true);
		resize(1250, 800);

		
	}
	public void actionPerformed(ActionEvent e)
  	{	
		counterTimer += 1;
		
		//Invader
		for(int k = 0; k < 3; k++) {
			Invaders[k].xDist += velX[k];
			Invaders[k].yDist += velY[k];
			repaint();
			if(Invaders[k].xDist <= xPositionInteger - 25) {
	  			velX[k] = 1;
	  		}
	  		else if(Invaders[k].xDist >= xPositionInteger - 25) {
	  			velX[k] = -1;
	  		}
			if(Invaders[k].yDist <= yPositionInteger - 50) {
	  			velY[k] = 1;
	  		}
	  		else if(Invaders[k].yDist >= yPositionInteger - 50) {
	  			velY[k] = -1;
	  		}
			if(Invaders[k].xDist >= xPositionInteger - 50 && Invaders[k].xDist <= xPositionInteger && Invaders[k].yDist >= yPositionInteger - 80 && Invaders[k].yDist <= yPositionInteger) {
				xPositionInteger = -10000;
			}
		}
		
		//Player
		if(xPositionInteger <= 1175) {
			if(rightOn == true) {
	   			xPositionInteger += xSpeed;
	   		}
		}
		if(xPositionInteger >= -30) {
			if(leftOn == true) {
	   			xPositionInteger -= xSpeed;
	   		}
		}
		if(yPositionInteger >= 0) {
			if(upOn == true) {
	   			yPositionInteger -= ySpeed;
	   		}
		}
		if(yPositionInteger <= 725) {
			if(downOn == true) {
	   			yPositionInteger += ySpeed;
	   		}
		}
		
		//Bullet
		if(paintBullet = true) {
			if(directionTracker == 3) {
				bulletX += bulletSpeed;
   			}
			else if(directionTracker == 2) {
				bulletX -= bulletSpeed;
   			}
			else if(directionTracker == 1) {
				bulletY -= bulletSpeed;
   			}
			else if(directionTracker == 4) {
				bulletY += bulletSpeed;
   			}
		}
		if(bulletY <= 0 || bulletY >= 800 || bulletX <= -100 || bulletX >= 1250) {
			paintBullet = false;
		}
		for(int l = 0; l < 3; l++) {
			if(bulletY >= Invaders[l].yDist + 10 && bulletY <= Invaders[l].yDist + 100 && bulletX >= Invaders[l].xDist - 30 && bulletX <= Invaders[l].xDist + 25) {
				Health[l] -= 1;
				paintBullet = false;
			}
			else if(Health[l] == 0) {
				randomizeZ = (int) (Math.random() * 2);
				if(randomizeZ == 0) {
					randomizeX = (int) (Math.random() * 2);
					if(randomizeX == 0) {
						Invaders[l].yDist = (int)(Math.random() * 800);
						Invaders[l].xDist = -100;
					}
					else if(randomizeX == 1) {
						Invaders[l].yDist = (int)(Math.random() * 800);
						Invaders[l].xDist = 1300;
					}
				}
				
				if(randomizeZ == 1) {
					randomizeY = (int) (Math.random() * 2);
					if(randomizeY == 0) {
						Invaders[l].xDist = (int)(Math.random() * 1300);
						Invaders[l].yDist = -100;
					}
					else if(randomizeY == 1) {
						Invaders[l].xDist = (int)(Math.random() * 1300);
						Invaders[l].yDist = 800;
					}
				}
				Health[l] = 3;
			}
		}
		if(paintBullet == false) {
			bulletY = -1000;
		}
		repaint();
  	}
	public void keyPressed(KeyEvent e)
	{
	   	int key = e.getKeyCode();
	   	//player movement
	   	if (key == 39) {
			rightOn = true;
	   	}
	   	if (key == 37) {
	   		leftOn = true;
	  	}
	   	if (key == 38) {
			upOn = true;
	   	}
	
	   	if (key == 40) {
	   		downOn = true;
	  	}
	   	//attack
	   	if(paintBullet == false) {
	   		if(key == 87) {	
	   			directionTracker = 1;
	   			bulletX = xPositionInteger - 25;
				bulletY = yPositionInteger;	
			}
	   		else if(key == 65) {
	   			directionTracker = 2;
	   			bulletX = xPositionInteger - 50;
				bulletY = yPositionInteger + 25;
	   		}
			else if(key == 68) {
				directionTracker = 3;
				bulletX = xPositionInteger;
				bulletY = yPositionInteger + 25;
			}
			else if(key == 83) {
				directionTracker = 4;
				bulletX = xPositionInteger -25;
				bulletY = yPositionInteger + 50;
			}
			paintBullet = true;
	   	}
	   	
	   	myTimer.start();
	}

	public void keyReleased(KeyEvent e)
	{
		//player movement
		int key = e.getKeyCode();
		if(key == 39) {
			rightOn = false;
		}
		if(key == 37) {
			leftOn = false;
		}
		if(key == 38) {
			upOn = false;
		}
		if(key == 40) {
			downOn = false;
		}
	}
	
	public void keyTyped(KeyEvent e)
	{

	}
	
	public void paint(Graphics gr)
	{
		//background color
		getContentPane().setBackground(Color.black);
		
		//Erase previous image and draw new one
		gr.setColor(getBackground());
		
	 	super.paint(gr);
	 	
	 	//draw player
	 	gr.drawImage(playerImage, xPositionInteger, yPositionInteger, 100, 75, this);
	 	
	 	//draw invader
	 	for(int i = 0; i < 3; i++) {
	 		gr.drawImage(invaderImage, Invaders[i].xDist, Invaders[i].yDist, 150, 120, this);
	 	}
		//draw bullet
 		if(paintBullet == true) {
			gr.setColor(Color.red);
			gr.fillOval(bulletX + 70, bulletY, 10, 10);
		}
	}
	public void Update(Graphics gr)
	{
		//call this the paint method
		paint(gr);	
	}
}

