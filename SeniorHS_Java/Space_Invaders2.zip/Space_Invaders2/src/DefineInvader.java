public class DefineInvader {
	int xDist,
		yDist;
	
	public void setInvader(int x, int y) {
		xDist = x;
		yDist = y;
	}
	
}
